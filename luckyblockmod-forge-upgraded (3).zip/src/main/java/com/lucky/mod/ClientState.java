package com.lucky.mod;

import java.util.Random;

/** Plain client-side state for flash / shake (no client class references, safe to load anywhere). */
public class ClientState {
    public static float flash = 0f;
    public static int flashColor = 0xFFF07A;
    public static float shakeAmp = 0f;
    public static int shakeTicks = 0;
    public static int shakeMax = 1;
    public static final Random RNG = new Random();

    public static void receive(float f, float shake, int duration, int color) {
        // Keep accessibility-friendly feedback: no opaque full-screen flashes or huge camera spins.
        float safeFlash = Math.max(0f, Math.min(f, 0.25f));
        if (safeFlash > flash) {
            flash = safeFlash;
            flashColor = color;
        }
        float current = shakeTicks > 0 ? shakeAmp * shakeTicks / shakeMax : 0f;
        float safeShake = Math.max(0f, Math.min(shake, 1.5f));
        if (safeShake >= current) {
            shakeAmp = safeShake;
            shakeMax = Math.max(1, Math.min(duration, 14));
            shakeTicks = shakeMax;
        }
    }

    public static void tick() {
        if (flash > 0) flash = Math.max(0f, flash - 0.035f);
        if (shakeTicks > 0) shakeTicks--;
    }
}
