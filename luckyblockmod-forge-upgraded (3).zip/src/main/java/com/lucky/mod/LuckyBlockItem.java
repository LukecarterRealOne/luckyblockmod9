package com.lucky.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Lucky Block: right-click casts the selected ability (random by default).
 * Sneak + right-click = Omega Beam. Press G for the ability menu.
 */
public class LuckyBlockItem extends Item {
    private static final DustParticleOptions YELLOW = new DustParticleOptions(new Vector3f(1.0f, 0.9f, 0.0f), 2.0f);
    private static final DustParticleOptions GOLD = new DustParticleOptions(new Vector3f(1.0f, 0.65f, 0.0f), 1.4f);
    private static final DustParticleOptions GREEN = new DustParticleOptions(new Vector3f(0.3f, 1.0f, 0.4f), 1.3f);

    public static final Map<UUID, Integer> SELECTED = new HashMap<>();
    public static final Set<UUID> SHIELDED = new HashSet<>();
    private static final Map<UUID, Integer> SHIELD_TOKENS = new HashMap<>();
    private static final Set<Integer> ENDED = new HashSet<>();
    private static final int[] COOLDOWNS = {100, 24, 28, 20, 24, 20, 40, 45, 70, 200, 180, 55, 25, 35, 30, 25, 20, 120,
            20, 80, 30, 45, 90, 25, 120, 60, 25, 45, 55, 15, 60, 45, 180, 35};
    private record PlayerSnapshot(Vec3 position, float health, float yaw, float pitch, ResourceKey<Level> dimension) {}
    private static final Map<UUID, Deque<PlayerSnapshot>> PLAYER_HISTORY = new HashMap<>();
    private static final int SNAPSHOT_CAPACITY = 100; // five seconds at 20 ticks/second
    private static int beamCounter = 0;
    private static List<EntityType<?>> PROJECTILE_TYPE_CACHE;

    public LuckyBlockItem(Properties properties) {
        super(properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§ePassive: §fDouble-speed flight while carried"));
        tooltip.add(Component.literal("§7Flight speed: 2× vanilla creative speed"));
        tooltip.add(Component.literal("§8Double-tap jump to take off"));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player user, InteractionHand hand) {
        ItemStack stack = user.getItemInHand(hand);
        if (!(level instanceof ServerLevel sw)) {
            return InteractionResultHolder.success(stack);
        }
        int a = user.isShiftKeyDown() ? 0 : SELECTED.getOrDefault(user.getUUID(), -1);
        if (a < 0 || a >= Abilities.COUNT) {
            a = level.random.nextInt(Abilities.COUNT);
        }
        castAbility(sw, user, a);
        user.getCooldowns().addCooldown(this, COOLDOWNS[a]);
        return InteractionResultHolder.success(stack);
    }

    public void castAbility(ServerLevel sw, Player user, int a) {
        switch (a) {
            case 0 -> omegaBeam(sw, user);
            case 1 -> lightningStorm(sw, user);
            case 2 -> meteorShower(sw, user);
            case 3 -> healingNova(sw, user);
            case 4 -> skyLaunch(sw, user);
            case 5 -> itemRain(sw, user);
            case 6 -> gravityWarp(sw, user);
            case 7 -> summonAllies(sw, user);
            case 8 -> orbitalStrike(sw, user);
            case 9 -> aegisShield(sw, user);
            case 10 -> guardianLegion(sw, user);
            case 11 -> blackHole(sw, user);
            case 12 -> frostNova(sw, user);
            case 13 -> tornado(sw, user);
            case 14 -> dragonBreath(sw, user);
            case 15 -> arrowStorm(sw, user);
            case 16 -> blinkStrike(sw, user);
            case 17 -> overdrive(sw, user);
            case 18 -> yellowFlight(sw, user);
            case 19 -> timeStop(sw, user);
            case 20 -> timeSurge(sw, user);
            case 21 -> voidRift(sw, user);
            case 22 -> giantTesseract(sw, user);
            case 23 -> allyCommand(sw, user);
            case 24 -> luckyAscension(sw, user);
            case 25 -> realityBreak(sw, user);
            case 26 -> chronoBurst(sw, user);
            case 27 -> dimensionShift(sw, user);
            case 28 -> cosmicNova(sw, user);
            case 29 -> itemWish(sw, user);
            case 30 -> timeReplay(sw, user);
            case 31 -> spatialDeflection(sw, user);
            case 32 -> absoluteAegis(sw, user);
            case 33 -> thunderGod(sw, user);
            default -> { }
        }
    }

    /** Called when the player clicks an ability in the G menu. */
    public static void onSelect(ServerPlayer player, int ability, boolean castNow) {
        if (ability < -1 || ability >= Abilities.COUNT) return;
        if (ability < 0) {
            SELECTED.remove(player.getUUID());
        } else {
            SELECTED.put(player.getUUID(), ability);
        }
        String name = ability < 0 ? "Random Roll" : Abilities.NAMES[ability];
        msg(player, "\u00a76Lucky Block ability: \u00a7e\u00a7l" + name);
        if (castNow && ability >= 0 && player.level() instanceof ServerLevel sw) {
            ItemStack held = player.getMainHandItem().getItem() instanceof LuckyBlockItem
                    ? player.getMainHandItem() : player.getOffhandItem();
            if (!(held.getItem() instanceof LuckyBlockItem item)) {
                msg(player, "\u00a7cHold the Lucky Block to cast from the menu");
                return;
            }
            if (player.getCooldowns().isOnCooldown(item)) {
                msg(player, "\u00a7cLucky Block is recharging!");
                return;
            }
            item.castAbility(sw, player, ability);
            player.getCooldowns().addCooldown(item, COOLDOWNS[ability]);
        }
    }

    // ---------------- helpers ----------------
    private static void msg(Player p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }

    private static boolean gone(ServerLevel sw, Player user) {
        return !user.isAlive() || user.isRemoved() || user.level() != sw;
    }

    private static boolean friend(Entity e, Player user) {
        return e == user || e.getTags().contains("lbm_ally");
    }

    /** Set an entity's velocity and make sure clients see it. */
    private static void launch(Entity e, double x, double y, double z) {
        e.setDeltaMovement(x, y, z);
        e.hurtMarked = true;
        e.hasImpulse = true;
    }

    /** Add to an entity's velocity and make sure clients see it. */
    private static void push(Entity e, double x, double y, double z) {
        Vec3 v = e.getDeltaMovement();
        launch(e, v.x + x, v.y + y, v.z + z);
    }

    private record Beam(Vec3 eye, Vec3 dir, double len, Vec3 impact) {}

    private static Beam aim(ServerLevel sw, Player user) {
        Vec3 eye = user.getEyePosition();
        Vec3 dir = user.getLookAngle();
        Vec3 end = eye.add(dir.scale(96));
        BlockHitResult hit = sw.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, user));
        boolean miss = hit.getType() == HitResult.Type.MISS;
        double len = miss ? 96 : eye.distanceTo(hit.getLocation());
        return new Beam(eye, dir, len, miss ? end : hit.getLocation());
    }

    private static Vec3[] basis(Vec3 dir) {
        Vec3 up = Math.abs(dir.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 right = dir.cross(up).normalize();
        Vec3 realUp = right.cross(dir).normalize();
        return new Vec3[]{right, realUp};
    }

    private record Target(Vec3 pos, LivingEntity entity) {}

    /** What the player is looking at: the nearest living entity on the ray, else the block hit (or far point). */
    private static Target pickTarget(ServerLevel sw, Player user, double range) {
        Vec3 eye = user.getEyePosition();
        Vec3 dir = user.getLookAngle();
        Vec3 end = eye.add(dir.scale(range));
        BlockHitResult hit = sw.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, user));
        boolean miss = hit.getType() == HitResult.Type.MISS;
        double bestT = miss ? range : eye.distanceTo(hit.getLocation());
        LivingEntity best = null;
        for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, new AABB(eye, end).inflate(2), x -> x != user)) {
            Vec3 c = e.position().add(0, e.getBbHeight() / 2, 0);
            double t = c.subtract(eye).dot(dir);
            if (t < 0 || t > bestT) continue;
            if (eye.add(dir.scale(t)).distanceTo(c) <= 1.5 + e.getBbWidth() / 2) {
                best = e;
                bestT = t;
            }
        }
        if (best != null) {
            return new Target(best.position().add(0, best.getBbHeight() / 2, 0), best);
        }
        return new Target(miss ? end : hit.getLocation(), null);
    }

    // ---------------- 0: YELLOW OMEGA BEAM ----------------
    // 1.5s charge-up -> 1.8s REAL laser (stretched block-display entities) you can sweep -> huge finale
    private static final double MUZZLE = 3.5;
    private static final String[] BEAM_BLOCKS = {
            "minecraft:yellow_stained_glass", "minecraft:yellow_stained_glass",
            "minecraft:yellow_concrete", "minecraft:white_concrete"};
    private static final double[] BEAM_WIDTHS = {6.0, 3.4, 1.7, 0.8};

    private void omegaBeam(ServerLevel sw, Player user) {
        msg(user, "\u00a7e\u00a7l\u26a1 CHARGING OMEGA BEAM... \u26a1");
        final int charge = 30;
        final int fire = 36;
        final int id = ++beamCounter;
        user.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, charge + 5, 4, false, false));
        Fx.sound(sw, user.blockPosition(), SoundEvents.BEACON_ACTIVATE, 3f, 0.5f);
        Fx.screen(sw, user.position(), 48, 0f, 0.5f, charge, 0xFFF07A);

        for (int t = 0; t < charge; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> chargeTick(sw, user, tt, charge));
        }
        Scheduler.later(charge + 1, () -> fireStart(sw, user));
        for (int t = 0; t < fire; t++) {
            final int tt = t;
            Scheduler.later(charge + 1 + t, () -> beamTick(sw, user, tt, fire, id));
        }
        Scheduler.later(charge + fire + 2, () -> finale(sw, user, id));
    }

    private void chargeTick(ServerLevel sw, Player user, int t, int total) {
        if (gone(sw, user)) return;
        float p = t / (float) total;
        Vec3 dir = user.getLookAngle();
        Vec3 c = user.getEyePosition().add(dir.scale(MUZZLE)).add(0, -0.3, 0);
        Vec3[] ax = basis(dir);
        double radius = 6.0 * (1 - p) + 0.4;
        int pts = 20;
        for (int i = 0; i < pts; i++) {
            double a = Math.PI * 2 * i / pts + t * 0.5;
            Vec3 o = ax[0].scale(Math.cos(a) * radius).add(ax[1].scale(Math.sin(a) * radius));
            Fx.burst(sw, GOLD, c.x + o.x, c.y + o.y, c.z + o.z, 1, 0, 0, 0, 0);
            if (i % 3 == 0) {
                Fx.burst(sw, ParticleTypes.END_ROD, c.x + o.x, c.y + o.y, c.z + o.z, 1, 0, 0, 0, 0);
            }
        }
        DustParticleOptions orb = new DustParticleOptions(new Vector3f(1f, 0.92f, 0.1f), 1f + 3f * p);
        Fx.burst(sw, orb, c.x, c.y, c.z, 6, 0.4, 0.4, 0.4, 0);
        if (t % 4 == 0) {
            Fx.sound(sw, user.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, 1.5f, 0.5f + 1.5f * p);
        }
        if (t == total - 4) {
            Fx.screen(sw, user.position(), 48, 0.35f, 1.2f, 6, 0xFFF07A);
        }
    }

    private void fireStart(ServerLevel sw, Player user) {
        if (gone(sw, user)) return;
        msg(user, "\u00a7e\u00a7l\u26a1 YELLOW OMEGA BEAM! \u26a1");
        Vec3 m = user.getEyePosition().add(user.getLookAngle().scale(MUZZLE));
        Fx.sound(sw, user.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, 4f, 0.7f);
        Fx.sound(sw, user.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, 3f, 1.4f);
        Fx.burst(sw, ParticleTypes.FLASH, m.x, m.y, m.z, 1, 0, 0, 0, 0);
        Fx.burst(sw, ParticleTypes.SONIC_BOOM, m.x, m.y, m.z, 1, 0, 0, 0, 0);
        Fx.screen(sw, user.position(), 80, 0.6f, 2.0f, 18, 0xFFF07A);
    }

    /** SNBT transformation that stretches a unit block into a w x w x len box pointing along q's local +Z. */
    private static String transformSnbt(Quaternionf q, double w, double len) {
        Vector3f tr = new Vector3f((float) (-w / 2), (float) (-w / 2), 0f);
        q.transform(tr);
        return String.format(Locale.ROOT,
                "transformation:{left_rotation:[%.5ff,%.5ff,%.5ff,%.5ff],right_rotation:[0f,0f,0f,1f],"
                        + "scale:[%.4ff,%.4ff,%.4ff],translation:[%.4ff,%.4ff,%.4ff]}",
                q.x, q.y, q.z, q.w, w, w, len, tr.x, tr.y, tr.z);
    }

    private void beamTick(ServerLevel sw, Player user, int t, int total, int id) {
        if (gone(sw, user)) return;
        Beam b = aim(sw, user);
        Vec3 dir = b.dir();
        Vec3 origin = b.eye().add(dir.scale(MUZZLE)).add(0, -0.3, 0);
        double len = Math.max(0.5, b.len() - MUZZLE);
        double grow = Math.min(1.0, (t + 1) / 4.0);
        if (t >= total - 4) grow = Math.min(grow, (total - t) / 4.0);
        double pulse = 1.0 + 0.06 * Math.sin(t * 1.7);
        Quaternionf q = new Quaternionf().rotationTo(0f, 0f, 1f, (float) dir.x, (float) dir.y, (float) dir.z);

        for (int k = 0; k < BEAM_BLOCKS.length; k++) {
            double w = BEAM_WIDTHS[k] * grow * pulse;
            String tf = transformSnbt(q, w, len);
            if (t == 0) {
                Fx.cmd(sw, String.format(Locale.ROOT,
                        "summon minecraft:block_display %.3f %.3f %.3f {block_state:{Name:\"%s\"},"
                                + "Tags:[\"lbm_beam\",\"lbm%d\",\"lbm%d_%d\"],view_range:4f,"
                                + "brightness:{sky:15,block:15},%s}",
                        origin.x, origin.y, origin.z, BEAM_BLOCKS[k], id, id, k, tf));
            } else {
                Fx.cmd(sw, String.format(Locale.ROOT,
                        "data merge entity @e[tag=lbm%d_%d,limit=1] {%s,start_interpolation:0,interpolation_duration:1}",
                        id, k, tf));
            }
        }
        if (t > 0) {
            Fx.cmd(sw, String.format(Locale.ROOT, "tp @e[tag=lbm%d] %.3f %.3f %.3f", id, origin.x, origin.y, origin.z));
        }

        Vec3[] ax = basis(dir);
        // Wider sampling and dotted twin spirals keep the beam dramatic without filling every pixel.
        for (double d = MUZZLE; d <= b.len(); d += 1.5) {
            Vec3 p = b.eye().add(dir.scale(d)).add(0, -0.3, 0);
            int idx = (int) (d / 1.5);
            if (idx % 2 == 0) {
                Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 2, 2.0, 2.0, 2.0, 0.3);
            }
            if (idx % 3 == 0) {
                Fx.burst(sw, ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 1.2, 1.2, 1.2, 0.03);
            }
            if (idx % 2 == 0) {
                double ang = d * 0.9 + t * 0.9;
                for (int side = 0; side < 2; side++) {
                    double a = ang + side * Math.PI;
                    double r = 3.0 * grow;
                    Vec3 o = ax[0].scale(Math.cos(a) * r).add(ax[1].scale(Math.sin(a) * r));
                    Fx.burst(sw, GOLD, p.x + o.x, p.y + o.y, p.z + o.z, 1, 0, 0, 0, 0);
                }
            }
        }

        if (t % 4 == 0) {
            damageAlong(sw, user, b, 70f, 4.5);
        }

        Vec3 im = b.impact();
        Fx.burst(sw, ParticleTypes.FLAME, im.x, im.y + 0.3, im.z, 14, 2.0, 0.6, 2.0, 0.08);
        Fx.burst(sw, ParticleTypes.LAVA, im.x, im.y + 0.3, im.z, 3, 2.0, 0.3, 2.0, 0);
        Fx.burst(sw, ParticleTypes.LARGE_SMOKE, im.x, im.y + 0.3, im.z, 7, 2.0, 0.8, 2.0, 0.04);
        Fx.burst(sw, YELLOW, im.x, im.y + 0.5, im.z, 14, 2.2, 0.8, 2.2, 0);
        if (t % 2 == 0) Fx.ring(sw, YELLOW, im.x, im.y + 0.2, im.z, 2 + (t % 10) * 0.8, 20);
        for (double y = 0; y <= 60; y += 2) {
            Fx.burst(sw, YELLOW, im.x, im.y + y, im.z, 4, 0.9, 0.1, 0.9, 0);
        }
        if (t % 6 == 0) {
            Fx.sound(sw, user.blockPosition(), SoundEvents.GENERIC_EXPLODE, 2f, 0.5f);
        }
    }

    private void damageAlong(ServerLevel sw, Player user, Beam b, float dmg, double radius) {
        Vec3 end = b.eye().add(b.dir().scale(b.len()));
        List<LivingEntity> targets = sw.getEntitiesOfClass(LivingEntity.class,
                new AABB(b.eye(), end).inflate(radius + 0.5), e -> !friend(e, user));
        for (LivingEntity e : targets) {
            Vec3 center = e.position().add(0, e.getBbHeight() / 2, 0);
            double t = Mth.clamp(center.subtract(b.eye()).dot(b.dir()), 0, b.len());
            Vec3 closest = b.eye().add(b.dir().scale(t));
            if (closest.distanceTo(center) <= radius) {
                e.hurt(sw.damageSources().indirectMagic(user, user), dmg);
                e.setSecondsOnFire(10);
                push(e, b.dir().x * 0.8, 0.3, b.dir().z * 0.8);
                Fx.burst(sw, ParticleTypes.EXPLOSION, e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(), 1, 0, 0, 0, 0);
            }
        }
    }

    private void finale(ServerLevel sw, Player user, int id) {
        Fx.cmd(sw, "kill @e[tag=lbm" + id + "]");
        if (gone(sw, user)) return;
        Beam b = aim(sw, user);
        Vec3 im = b.impact();
        sw.explode(user, im.x, im.y, im.z, 8f, Level.ExplosionInteraction.NONE);
        Fx.epicImpact(sw, im, YELLOW, ParticleTypes.ELECTRIC_SPARK, 10.5, 0xFFF07A);
        Fx.sound(sw, user.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, 4f, 0.6f);
        damageAlong(sw, user, b, 100f, 6.0);
        for (int k = 0; k < 4; k++) {
            final double r = 2 + k * 4;
            Scheduler.later(k * 2 + 1, () -> {
                Fx.ring(sw, YELLOW, im.x, im.y + 0.3, im.z, r, 28);
                Fx.ring(sw, ParticleTypes.END_ROD, im.x, im.y + 0.6, im.z, r, 20);
            });
        }
    }

    // ---------------- 1: LIGHTNING STORM ----------------
    private void lightningStorm(ServerLevel sw, Player user) {
        msg(user, "\u00a7b\u00a7lLightning Storm!");
        for (int i = 0; i < 24; i++) {
            double a = sw.random.nextDouble() * Math.PI * 2;
            double r = 4 + sw.random.nextDouble() * 7;
            final Vec3 pos = user.position().add(Math.cos(a) * r, 0, Math.sin(a) * r);
            Scheduler.later(i * 2 + 1, () -> {
                if (gone(sw, user)) return;
                Fx.ring(sw, ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y + 0.1, pos.z, 2.0, 24);
                Fx.sound(sw, user.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, 1.5f, 1.8f);
            });
            Scheduler.later(i * 2 + 8, () -> {
                if (gone(sw, user)) return;
                LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sw);
                if (bolt != null) {
                    bolt.moveTo(pos.x, pos.y, pos.z);
                    sw.addFreshEntity(bolt);
                }
                Fx.burst(sw, ParticleTypes.FLASH, pos.x, pos.y + 0.8, pos.z, 1, 0, 0, 0, 0);
                Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y + 1, pos.z, 18, 0.45, 0.9, 0.45, 0.25);
                Fx.line(sw, ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y + 10, pos.z,
                        pos.x + (sw.random.nextDouble() - 0.5) * 1.5, pos.y + 1, pos.z + (sw.random.nextDouble() - 0.5) * 1.5, 7);
                Fx.ring(sw, ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y + 0.1, pos.z, 1.6, 14);
                Fx.ring(sw, ParticleTypes.END_ROD, pos.x, pos.y + 0.15, pos.z, 2.5, 12);
                if (i % 4 == 0) Fx.screen(sw, pos, 64, 0.28f, 0.7f, 8, 0xBFE9FF);
            });
        }
    }

    // ---------------- 2: METEOR SHOWER ----------------
    private void meteorShower(ServerLevel sw, Player user) {
        msg(user, "\u00a7c\u00a7lMeteor Shower!");
        Vec3 target = user.getEyePosition().add(user.getLookAngle().scale(18));
        List<LargeFireball> fireballs = new ArrayList<>();
        Fx.screen(sw, user.position(), 64, 0.3f, 0.8f, 20, 0xFF7A1A);
        for (int i = 0; i < 8; i++) {
            final Vec3 start = target.add((sw.random.nextDouble() - 0.5) * 12, 25 + sw.random.nextDouble() * 8,
                    (sw.random.nextDouble() - 0.5) * 12);
            Scheduler.later(i * 4 + 1, () -> {
                LargeFireball fb = new LargeFireball(sw, user, 0, -1.2, 0, 2);
                fb.setPos(start.x, start.y, start.z);
                sw.addFreshEntity(fb);
                fireballs.add(fb);
                Fx.burst(sw, ParticleTypes.FLAME, start.x, start.y, start.z, 16, 0.45, 0.45, 0.45, 0.08);
                Fx.sound(sw, user.blockPosition(), SoundEvents.BLAZE_SHOOT, 2f, 0.6f);
            });
        }
        trail(sw, fireballs, 70);
    }

    private void trail(ServerLevel sw, List<LargeFireball> fireballs, int remaining) {
        if (remaining % 2 == 0) {
            for (LargeFireball fb : new ArrayList<>(fireballs)) {
                if (!fb.isRemoved()) {
                    Fx.burst(sw, ParticleTypes.FLAME, fb.getX(), fb.getY(), fb.getZ(), 3, 0.22, 0.22, 0.22, 0.02);
                    Fx.burst(sw, ParticleTypes.LARGE_SMOKE, fb.getX(), fb.getY(), fb.getZ(), 1, 0.18, 0.18, 0.18, 0.01);
                    if (remaining % 12 == 0) Fx.burst(sw, ParticleTypes.LAVA, fb.getX(), fb.getY(), fb.getZ(), 1, 0.08, 0.08, 0.08, 0);
                } else {
                    // Once each meteor disappears, play one compact impact burst at its last position.
                    Vec3 impact = new Vec3(fb.getX(), fb.getY(), fb.getZ());
                    DustParticleOptions ember = new DustParticleOptions(new Vector3f(1.0f, 0.28f, 0.045f), 1.7f);
                    Fx.epicImpact(sw, impact, ember, ParticleTypes.FLAME, 4.8, 0xFF7A1A);
                    Fx.sound(sw, BlockPos.containing(impact.x, impact.y, impact.z), SoundEvents.GENERIC_EXPLODE, 2.2f, 0.78f);
                    fireballs.remove(fb);
                }
            }
        }
        if (remaining > 0) {
            Scheduler.later(1, () -> trail(sw, fireballs, remaining - 1));
        }
    }

    // ---------------- 3: HEALING NOVA ----------------
    private void healingNova(ServerLevel sw, Player user) {
        msg(user, "\u00a7a\u00a7lHealing Nova!");
        user.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 2));
        user.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 600, 3));
        user.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 1));
        user.setHealth(user.getMaxHealth());
        for (LivingEntity entity : sw.getEntitiesOfClass(LivingEntity.class, new AABB(user.blockPosition()).inflate(18), e -> e.isAlive())) {
            entity.setHealth(entity.getMaxHealth());
            entity.removeEffect(MobEffects.POISON);
            entity.removeEffect(MobEffects.WITHER);
            entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
            entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 240, 3));
            entity.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 400, 1));
        }
        Fx.sound(sw, user.blockPosition(), SoundEvents.BEACON_POWER_SELECT, 2f, 1.2f);
        Fx.screen(sw, user.position(), 32, 0.3f, 0f, 1, 0x66FF99);
        for (int t = 0; t < 10; t++) {
            final int tt = t;
            Scheduler.later(t * 2 + 1, () -> {
                if (gone(sw, user)) return;
                double x = user.getX(), y = user.getY(), z = user.getZ();
                Fx.ring(sw, ParticleTypes.HAPPY_VILLAGER, x, y + 0.1, z, 0.6 + tt * 0.65, 24);
                if (tt % 2 == 0) Fx.ring(sw, GREEN, x, y + 0.2, z, 0.6 + tt * 0.65, 20);
                double a = tt * 0.7;
                Fx.burst(sw, GOLD, x + Math.cos(a), y + tt * 0.12, z + Math.sin(a), 1, 0.05, 0.05, 0.05, 0);
                if (tt == 9) Fx.burst(sw, ParticleTypes.HEART, x, y + 1.5, z, 14, 0.5, 0.6, 0.5, 0.08);
            });
        }
    }

    // ---------------- 4: SKY LAUNCH ----------------
    private void skyLaunch(ServerLevel sw, Player user) {
        msg(user, "\u00a7d\u00a7lSky Launch!");
        push(user, 0, 2.2, 0);
        user.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 300, 0));
        Fx.sound(sw, user.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, 2f, 1f);
        Fx.screen(sw, user.position(), 48, 0.5f, 2.0f, 8, 0xFFFFFF);
        for (int k = 1; k <= 4; k++) {
            Fx.ring(sw, ParticleTypes.CLOUD, user.getX(), user.getY() + 0.1, user.getZ(), k, 32);
        }
        for (int t = 0; t < 25; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                if (gone(sw, user)) return;
                double x = user.getX(), y = user.getY(), z = user.getZ();
                Fx.burst(sw, ParticleTypes.FIREWORK, x, y, z, 6, 0.2, 0.1, 0.2, 0.05);
                Fx.burst(sw, ParticleTypes.CLOUD, x, y, z, 4, 0.3, 0.1, 0.3, 0.02);
                Fx.burst(sw, ParticleTypes.FLAME, x, y, z, 3, 0.15, 0.05, 0.15, 0.02);
                if (tt % 5 == 0) {
                    Fx.ring(sw, ParticleTypes.END_ROD, x, y, z, 1 + tt * 0.1, 20);
                }
            });
        }
    }

    // ---------------- 5: ITEM RAIN ----------------
    // Rains RANDOM items from the whole item registry: vanilla AND every installed mod.
    private void itemRain(ServerLevel sw, Player user) {
        List<Item> all = new ArrayList<>();
        for (Item item : ForgeRegistries.ITEMS) {
            if (item != Items.AIR) all.add(item);
        }
        msg(user, "\u00a76\u00a7lITEM RAIN! (" + all.size() + " possible items)");
        final Vec3 base = user.position();
        Fx.sound(sw, user.blockPosition(), SoundEvents.PLAYER_LEVELUP, 2f, 1f);
        Fx.screen(sw, base, 32, 0.35f, 0.6f, 10, 0xFFD84A);
        // A short gold shimmer marks the drop zone; item entities are the main effect.
        for (int t = 0; t < 14; t += 2) {
            final int tick = t;
            Scheduler.later(t + 1, () -> {
                for (double y = 1; y <= 13; y += 3) {
                    Fx.burst(sw, GOLD, base.x, base.y + y, base.z, 1, 0.25, 0, 0.25, 0);
                }
                if (tick == 12) Fx.burst(sw, ParticleTypes.TOTEM_OF_UNDYING, base.x, base.y + 1, base.z, 24, 1, 1, 1, 0.12);
            });
        }
        for (int i = 0; i < 30; i++) {
            Item item = all.get(sw.random.nextInt(all.size()));
            int count = 1 + sw.random.nextInt(Math.max(1, Math.min(item.getMaxStackSize(), 16)));
            ItemStack loot = new ItemStack(item, count);
            final double x = base.x + (sw.random.nextDouble() - 0.5) * 6;
            final double z = base.z + (sw.random.nextDouble() - 0.5) * 6;
            final double y = base.y + 5 + sw.random.nextDouble() * 3;
            Scheduler.later(i * 2 + 2, () -> {
                sw.addFreshEntity(new ItemEntity(sw, x, y, z, loot));
                Fx.burst(sw, ParticleTypes.TOTEM_OF_UNDYING, x, y, z, 4, 0.16, 0.16, 0.16, 0.2);
            });
        }
    }

    // ---------------- 6: GRAVITY WARP ----------------
    private void gravityWarp(ServerLevel sw, Player user) {
        msg(user, "\u00a75\u00a7lGRAVITY WARP!");
        Target tg = pickTarget(sw, user, 48);
        final Vec3 c = tg.pos();
        final double r = 14;
        final List<LivingEntity> victims = sw.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(r),
                e -> !friend(e, user) && e.distanceToSqr(c) <= r * r);
        final DustParticleOptions purple = new DustParticleOptions(new Vector3f(0.6f, 0.2f, 1.0f), 1.6f);

        Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.BEACON_ACTIVATE, 3f, 0.6f);
        Fx.screen(sw, c, 64, 0.3f, 1.0f, 10, 0xAA66FF);
        for (LivingEntity e : victims) {
            e.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 60, 3, false, true));
            e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 80, 0, false, false));
        }
        for (int t = 0; t < 36; t += 2) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                double rise = (tt % 24) * 0.5;
                // A rising double helix reads as a gravity column instead of a wall of rings.
                for (int point = 0; point < 10; point++) {
                    double a = point * Math.PI * 2 / 10.0 + tt * 0.12;
                    double h = (point / 10.0) * 7.0;
                    Fx.burst(sw, purple, c.x + Math.cos(a) * r * 0.55, c.y + rise + h,
                            c.z + Math.sin(a) * r * 0.55, 1, 0, 0, 0, 0);
                }
                for (LivingEntity e : victims) {
                    if (e.isAlive() && tt % 6 == 0) {
                        Fx.burst(sw, ParticleTypes.PORTAL, e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(),
                                2, 0.2, 0.3, 0.2, 0.08);
                    }
                }
                if (tt % 12 == 0) {
                    Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.BEACON_AMBIENT, 1.6f, 0.6f);
                }
            });
        }
        Scheduler.later(62, () -> {
            for (LivingEntity e : victims) {
                if (!e.isAlive()) continue;
                e.removeEffect(MobEffects.LEVITATION);
                launch(e, 0, -3.5, 0);
                e.hurt(sw.damageSources().magic(), 36f);
            }
            Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.GENERIC_EXPLODE, 3.2f, 0.62f);
            Fx.epicImpact(sw, c, purple, ParticleTypes.PORTAL, 9.5, 0xAA66FF);
            for (int k = 0; k < 4; k++) {
                final double rr = 3 + k * 3.2;
                Scheduler.later(k * 2 + 1, () -> Fx.ring(sw, purple, c.x, c.y + 0.15, c.z, rr, 18));
            }
        });
    }

    // ---------------- 7: ALLY SUMMON (instant, works with modded mobs) ----------------
    private Mob spawnAlly(ServerLevel sw, Player user, EntityType<?> type, Vec3 pos, boolean guardian) {
        Entity e = null;
        try {
            e = type.create(sw);
        } catch (Exception ignored) {
        }
        if (!(e instanceof Mob mob)) return null;
        mob.moveTo(pos.x, pos.y, pos.z, user.getYRot(), 0f);
        try {
            mob.finalizeSpawn(sw, sw.getCurrentDifficultyAt(mob.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
        } catch (Exception ignored) {
        }
        if (mob instanceof IronGolem golem) golem.setPlayerCreated(true);
        mob.setPersistenceRequired();
        mob.addTag("lbm_ally");
        mob.addTag("lbm_owner_" + user.getUUID());
        int dur = guardian ? 2500 : 1300;
        int amp = guardian ? 2 : 1;
        mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, dur, amp));
        mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, dur, amp));
        mob.addEffect(new MobEffectInstance(MobEffects.REGENERATION, dur, 1));
        mob.addEffect(new MobEffectInstance(MobEffects.GLOWING, dur, 0, false, false));
        if (guardian) {
            mob.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, dur, 4));
            mob.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, dur, 0));
            mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, dur, 1));
            mob.setCustomName(Component.literal("\u00a7b\u00a7lGuardian"));
            mob.setCustomNameVisible(true);
        }
        mob.setTarget(null);   // friendly from the very first tick
        sw.addFreshEntity(mob);

        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sw);
        if (bolt != null) {
            bolt.moveTo(pos.x, pos.y, pos.z);
            bolt.setVisualOnly(true);
            sw.addFreshEntity(bolt);
        }
        Fx.ring(sw, ParticleTypes.SOUL_FIRE_FLAME, pos.x, pos.y + 0.1, pos.z, 2.0, 24);
        Fx.burst(sw, ParticleTypes.END_ROD, pos.x, pos.y + 1, pos.z, 30, 0.3, 1.2, 0.3, 0.1);
        Fx.burst(sw, ParticleTypes.PORTAL, pos.x, pos.y + 1, pos.z, 40, 0.6, 1.0, 0.6, 0.5);
        return mob;
    }

    private void summonAllies(ServerLevel sw, Player user) {
        List<EntityType<?>> modded = new ArrayList<>();
        for (ResourceLocation id : ForgeRegistries.ENTITY_TYPES.getKeys()) {
            String ns = id.getNamespace();
            if (ns.equals("minecraft") || ns.equals(LuckyBlockMod.MOD_ID)) continue;
            EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(id);
            if (type == null || type.getCategory() == MobCategory.MISC || !type.canSummon()) continue;
            modded.add(type);
        }
        List<EntityType<?>> fallback = List.<EntityType<?>>of(EntityType.IRON_GOLEM, EntityType.WOLF,
                EntityType.WOLF, EntityType.VINDICATOR, EntityType.IRON_GOLEM);

        msg(user, modded.isEmpty()
                ? "\u00a7b\u00a7lAllies Summoned!"
                : "\u00a7b\u00a7lModded Allies Summoned! (" + modded.size() + " mob types found)");

        final int total = 5;
        final List<Mob> allies = new ArrayList<>();
        final Set<UUID> ids = new HashSet<>();
        StringBuilder names = new StringBuilder();
        // everything spawns in the SAME tick
        for (int i = 0; i < total; i++) {
            double a = Math.PI * 2 * i / total;
            Vec3 pos = user.position().add(Math.cos(a) * 3.5, 0, Math.sin(a) * 3.5);
            Mob mob = null;
            for (int attempt = 0; attempt < 6 && mob == null; attempt++) {
                EntityType<?> type = (!modded.isEmpty() && i < 4 && attempt < 5)
                        ? modded.get(sw.random.nextInt(modded.size()))
                        : fallback.get(i % fallback.size());
                mob = spawnAlly(sw, user, type, pos, false);
            }
            if (mob != null) {
                allies.add(mob);
                ids.add(mob.getUUID());
                if (names.length() > 0) names.append(", ");
                names.append(mob.getType().getDescription().getString());
            }
        }
        user.sendSystemMessage(Component.literal("\u00a7bSummoned: " + names));
        Fx.sound(sw, user.blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON, 3f, 1f);
        allyTick(sw, user, allies, ids, 1200, 100.0);
    }

    // ---------------- 10: GUARDIAN LEGION ----------------
    private void guardianLegion(ServerLevel sw, Player user) {
        msg(user, "\u00a7b\u00a7lGUARDIAN LEGION!");
        final List<Mob> allies = new ArrayList<>();
        final Set<UUID> ids = new HashSet<>();
        int total = 6;
        for (int i = 0; i < total; i++) {
            double a = Math.PI * 2 * i / total;
            Vec3 pos = user.position().add(Math.cos(a) * 4.5, 0, Math.sin(a) * 4.5);
            Mob mob = spawnAlly(sw, user, EntityType.IRON_GOLEM, pos, true);
            if (mob != null) {
                allies.add(mob);
                ids.add(mob.getUUID());
            }
        }
        Fx.sound(sw, user.blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON, 3f, 0.7f);
        Fx.screen(sw, user.position(), 48, 0.4f, 2.0f, 12, 0x88DDFF);
        for (int k = 0; k < 5; k++) {
            final double r = 2 + k * 2.5;
            Scheduler.later(k + 1, () -> Fx.ring(sw, ParticleTypes.END_ROD, user.getX(), user.getY() + 0.2, user.getZ(), r, 40));
        }
        allyTick(sw, user, allies, ids, 2400, 36.0);
    }

    private void allyTick(ServerLevel sw, Player user, List<Mob> allies, Set<UUID> ids, int remaining, double followSq) {
        boolean any = false;
        LivingEntity attacker = user.getLastHurtByMob();
        for (Mob a : allies) {
            if (a.isRemoved() || !a.isAlive()) continue;
            any = true;
            if (remaining <= 0) {
                Fx.burst(sw, ParticleTypes.POOF, a.getX(), a.getY() + 1, a.getZ(), 30, 0.5, 0.8, 0.5, 0.05);
                a.discard();
                continue;
            }
            LivingEntity tgt = a.getTarget();
            if (tgt instanceof Player || (tgt != null && ids.contains(tgt.getUUID()))) {
                a.setTarget(null);
            }
            // protect the owner: go after whatever hurt them
            if (attacker != null && attacker.isAlive() && !(attacker instanceof Player)
                    && !ids.contains(attacker.getUUID())) {
                a.setTarget(attacker);
            }
            LivingEntity cur = a.getTarget();
            if ((cur == null || !cur.isAlive()) && remaining % 5 == 0) {
                Mob best = null;
                double bd = Double.MAX_VALUE;
                for (Mob f : sw.getEntitiesOfClass(Mob.class, a.getBoundingBox().inflate(20),
                        m -> m instanceof Enemy && m.isAlive() && !ids.contains(m.getUUID()))) {
                    double d = a.distanceToSqr(f);
                    if (d < bd) {
                        bd = d;
                        best = f;
                    }
                }
                if (best != null) {
                    a.setTarget(best);
                } else if (a.distanceToSqr(user) > followSq) {
                    a.getNavigation().moveTo(user, 1.3);
                }
            }
        }
        if (any && remaining > 0) {
            Scheduler.later(1, () -> allyTick(sw, user, allies, ids, remaining - 1, followSq));
        }
    }

    // ---------------- 8: ORBITAL STRIKE ----------------
    private static final String[] ORB_BLOCKS = {
            "minecraft:cyan_stained_glass", "minecraft:light_blue_stained_glass", "minecraft:white_concrete"};
    private static final double[] ORB_WIDTHS = {18.0, 11.0, 5.5};

    private static String verticalBeamSnbt(double w, double h) {
        return String.format(Locale.ROOT,
                "transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],"
                        + "scale:[%.4ff,%.4ff,%.4ff],translation:[%.4ff,0f,%.4ff]}",
                w, h, w, -w / 2, -w / 2);
    }

    private void orbitalStrike(ServerLevel sw, Player user) {
        Target tg = pickTarget(sw, user, 128);
        final Vec3 c = tg.pos();
        final int charge = 32;
        final int fire = 42;
        final int id = ++beamCounter;
        final BlockPos bp = BlockPos.containing(c.x, c.y, c.z);
        final DustParticleOptions cyan = new DustParticleOptions(new Vector3f(0.3f, 0.9f, 1.0f), 2.0f);

        msg(user, "\u00a7b\u00a7lORBITAL STRIKE LOCKED ON!");
        Fx.sound(sw, bp, SoundEvents.BEACON_ACTIVATE, 4f, 0.5f);

        for (int t = 0; t < charge; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                float p = tt / (float) charge;
                double radius = 12 * (1 - p) + 1;
                if (tt % 2 == 0) {
                    Fx.ring(sw, cyan, c.x, c.y + 0.2, c.z, radius, 24);
                    Fx.ring(sw, cyan, c.x, c.y + 0.2, c.z, 12, 24);
                    Fx.ring(sw, ParticleTypes.END_ROD, c.x, c.y + 0.3, c.z, 4, 12);
                }
                for (double y = 0; y <= 80; y += 8) {
                    Fx.burst(sw, ParticleTypes.END_ROD, c.x, c.y + y, c.z, 1, 0.05, 0, 0.05, 0);
                }
                if (tt % 5 == 0) {
                    Fx.sound(sw, bp, SoundEvents.EXPERIENCE_ORB_PICKUP, 3f, 0.5f + 1.5f * p);
                }
                if (tt == charge - 5) {
                    Fx.screen(sw, c, 200, 0.4f, 1.5f, 6, 0xBFEFFF);
                }
            });
        }
        for (int t = 0; t < fire; t++) {
            final int tt = t;
            Scheduler.later(charge + 1 + t, () -> orbitalTick(sw, user, c, cyan, tt, fire, id));
        }
        Scheduler.later(charge + fire + 2, () -> orbitalFinale(sw, user, c, cyan, id));
    }

    private void orbitalTick(ServerLevel sw, Player user, Vec3 c, DustParticleOptions cyan, int t, int total, int id) {
        double grow = Math.min(1.0, (t + 1) / 2.0);
        if (t >= total - 6) grow = Math.min(grow, (total - t) / 6.0);
        double pulse = 1.0 + 0.05 * Math.sin(t * 1.9);

        for (int k = 0; k < ORB_BLOCKS.length; k++) {
            double w = ORB_WIDTHS[k] * grow * pulse;
            String tf = verticalBeamSnbt(w, 400);
            if (t == 0) {
                Fx.cmd(sw, String.format(Locale.ROOT,
                        "summon minecraft:block_display %.3f %.3f %.3f {block_state:{Name:\"%s\"},"
                                + "Tags:[\"lbm_beam\",\"lbm%d\",\"lbm%d_%d\"],view_range:8f,"
                                + "brightness:{sky:15,block:15},%s}",
                        c.x, c.y - 2, c.z, ORB_BLOCKS[k], id, id, k, tf));
            } else if (t % 2 == 0) {
                Fx.cmd(sw, String.format(Locale.ROOT,
                        "data merge entity @e[tag=lbm%d_%d,limit=1] {%s,start_interpolation:0,interpolation_duration:2}",
                        id, k, tf));
            }
        }
        if (t == 0) {
            BlockPos bp = BlockPos.containing(c.x, c.y, c.z);
            Fx.sound(sw, bp, SoundEvents.WARDEN_SONIC_BOOM, 6f, 0.5f);
            Fx.sound(sw, bp, SoundEvents.LIGHTNING_BOLT_THUNDER, 6f, 0.8f);
            Fx.screen(sw, c, 180, 0.65f, 3.0f, 28, 0xBFEFFF);
        }
        if (t % 3 == 0) {
            AABB zone = new AABB(c.x - 9, c.y - 6, c.z - 9, c.x + 9, c.y + 60, c.z + 9);
            for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, zone, e -> !friend(e, user))) {
                double dx = e.getX() - c.x;
                double dz = e.getZ() - c.z;
                if (dx * dx + dz * dz <= 81) {
                    e.hurt(sw.damageSources().indirectMagic(user, user), 60f);
                    e.setSecondsOnFire(10);
                    push(e, 0, 0.6, 0);
                }
            }
        }
        Fx.burst(sw, ParticleTypes.FLAME, c.x, c.y + 0.3, c.z, 9, 3.0, 0.7, 3.0, 0.06);
        Fx.burst(sw, ParticleTypes.LAVA, c.x, c.y + 0.3, c.z, 2, 2.5, 0.3, 2.5, 0);
        Fx.burst(sw, ParticleTypes.LARGE_SMOKE, c.x, c.y + 0.3, c.z, 4, 3.0, 0.8, 3.0, 0.03);
        Fx.burst(sw, cyan, c.x, c.y + 0.5, c.z, 8, 3.0, 0.8, 3.0, 0);
        if (t % 3 == 0) Fx.ring(sw, cyan, c.x, c.y + 0.2, c.z, 3 + (t % 12) * 1.0, 24);
        if (t % 6 == 0) for (double y = 0; y <= 40; y += 8) {
            Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, c.x, c.y + y, c.z, 1, 2.0, 0.8, 2.0, 0.2);
        }
        if (t % 6 == 0) {
            Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.GENERIC_EXPLODE, 4f, 0.5f);
        }
    }

    private void orbitalFinale(ServerLevel sw, Player user, Vec3 c, DustParticleOptions cyan, int id) {
        Fx.cmd(sw, "kill @e[tag=lbm" + id + "]");
        sw.explode(user, c.x, c.y, c.z, 10f, Level.ExplosionInteraction.NONE);
        Fx.epicImpact(sw, c, cyan, ParticleTypes.END_ROD, 15.0, 0xBFEFFF);
        Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.LIGHTNING_BOLT_THUNDER, 6f, 0.5f);
        AABB zone = new AABB(c.x - 12, c.y - 8, c.z - 12, c.x + 12, c.y + 20, c.z + 12);
        for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, zone, e -> !friend(e, user))) {
            if (e.distanceToSqr(c) <= 144) {
                e.hurt(sw.damageSources().indirectMagic(user, user), 100f);
                e.setSecondsOnFire(10);
            }
        }
        for (int k = 0; k < 5; k++) {
            final double r = 3 + k * 4;
            Scheduler.later(k * 2 + 1, () -> {
                Fx.ring(sw, cyan, c.x, c.y + 0.3, c.z, r, 18);
                Fx.ring(sw, ParticleTypes.END_ROD, c.x, c.y + 0.6, c.z, r * 0.78, 18);
            });
        }
    }

    // ---------------- 9: AEGIS SHIELD ----------------
    // 20s active force field: reduces damage, reflects projectiles, and blasts hostiles away.
    // Absolute Aegis is the separate upgrade that grants full damage cancellation.
    private void aegisShield(ServerLevel sw, Player user) {
        msg(user, "\u00a7b\u00a7lAEGIS SHIELD ACTIVE!");
        final int id = ++beamCounter;
        final int total = 400;
        user.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, total, 2));
        user.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, total, 1));
        Fx.sound(sw, user.blockPosition(), SoundEvents.BEACON_ACTIVATE, 3f, 1.4f);
        Fx.screen(sw, user.position(), 32, 0.4f, 1.0f, 8, 0x88DDFF);
        for (int t = 0; t < total; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> shieldTick(sw, user, tt, total, id));
        }
        Scheduler.later(total + 2, () -> shieldEnd(sw, user, id));
    }

    private void shieldTick(ServerLevel sw, Player user, int t, int total, int id) {
        if (ENDED.contains(id)) return;
        if (gone(sw, user)) {
            shieldEnd(sw, user, id);
            return;
        }
        final DustParticleOptions blue = new DustParticleOptions(new Vector3f(0.4f, 0.85f, 1.0f), 1.5f);
        Vec3 c = user.position().add(0, 1.0, 0);
        if (t == 0) {
            Fx.cmd(sw, String.format(Locale.ROOT,
                    "summon minecraft:block_display %.3f %.3f %.3f {block_state:{Name:\"minecraft:light_blue_stained_glass\"},"
                            + "Tags:[\"lbm_beam\",\"lbm%d\"],view_range:4f,brightness:{sky:15,block:15},"
                            + "transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],"
                            + "scale:[6.5f,6.5f,6.5f],translation:[-3.25f,-2.2f,-3.25f]}}",
                    user.getX(), user.getY(), user.getZ(), id));
        } else if (t % 4 == 0) {
            Fx.cmd(sw, String.format(Locale.ROOT, "tp @e[tag=lbm%d] %.3f %.3f %.3f", id, user.getX(), user.getY(), user.getZ()));
        }
        if (t % 4 == 0) {
            for (int i = 0; i < 14; i++) {
                double y = 1 - 2 * (i + 0.5) / 14;
                double rr = Math.sqrt(1 - y * y);
                double a = i * 2.399963 + t * 0.08;
                double px = c.x + Math.cos(a) * rr * 3.5;
                double py = c.y + y * 3.5;
                double pz = c.z + Math.sin(a) * rr * 3.5;
                Fx.burst(sw, blue, px, py, pz, 1, 0, 0, 0, 0);
                if (i % 5 == 0) Fx.burst(sw, ParticleTypes.END_ROD, px, py, pz, 1, 0, 0, 0, 0);
            }
        }
        user.clearFire();
        // deflect every projectile that gets close (arrows, fireballs, tridents, mod projectiles...)
        for (Projectile p : sw.getEntitiesOfClass(Projectile.class, new AABB(c, c).inflate(7),
                p -> p.getOwner() != user && !p.getTags().contains("lbm_ally"))) {
            if (p.position().distanceTo(c) > 6.5) continue;
            Vec3 away = p.position().subtract(c);
            if (away.lengthSqr() < 0.01) away = new Vec3(0, 1, 0);
            away = away.normalize();
            double speed = Math.max(1.5, p.getDeltaMovement().length() * 1.2);
            launch(p, away.x * speed, away.y * speed + 0.05, away.z * speed);
            p.setOwner(user);
            Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY(), p.getZ(), 12, 0.2, 0.2, 0.2, 0.3);
            Fx.sound(sw, p.blockPosition(), SoundEvents.SHIELD_BLOCK, 1.5f, 1.2f);
        }
        // blast hostile mobs back
        if (t % 2 == 0) {
            for (Mob m : sw.getEntitiesOfClass(Mob.class, new AABB(c, c).inflate(6),
                    m -> m instanceof Enemy && !m.getTags().contains("lbm_ally"))) {
                Vec3 away = m.position().subtract(user.position());
                away = new Vec3(away.x, 0, away.z);
                if (away.lengthSqr() < 0.01) away = new Vec3(1, 0, 0);
                away = away.normalize().scale(1.3);
                push(m, away.x, 0.35, away.z);
                Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, m.getX(), m.getY() + 1, m.getZ(), 6, 0.3, 0.5, 0.3, 0.2);
            }
        }
        if (t == total - 40) {
            msg(user, "\u00a7c\u00a7lShield ending soon...");
        }
    }

    private void shieldEnd(ServerLevel sw, Player user, int id) {
        if (!ENDED.add(id)) return;
        Fx.cmd(sw, "kill @e[tag=lbm" + id + "]");
        Fx.sound(sw, user.blockPosition(), SoundEvents.GLASS_BREAK, 3f, 0.8f);
        Fx.burst(sw, ParticleTypes.END_ROD, user.getX(), user.getY() + 1, user.getZ(), 80, 3, 2, 3, 0.2);
    }

    // ---------------- 11: BLACK HOLE ----------------
    private void blackHole(ServerLevel sw, Player user) {
        msg(user, "\u00a78\u00a7lBLACK HOLE!");
        Target tg = pickTarget(sw, user, 60);
        final Vec3 c = tg.pos().add(0, 1.5, 0);
        final int id = ++beamCounter;
        final int total = 120;
        Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.BEACON_ACTIVATE, 4f, 0.5f);
        Fx.cmd(sw, String.format(Locale.ROOT,
                "summon minecraft:block_display %.3f %.3f %.3f {block_state:{Name:\"minecraft:black_concrete\"},"
                        + "Tags:[\"lbm_beam\",\"lbm%d\"],view_range:4f,"
                        + "transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],"
                        + "scale:[3f,3f,3f],translation:[-1.5f,-1.5f,-1.5f]}}",
                c.x, c.y, c.z, id));
        for (int t = 0; t < total; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> holeTick(sw, user, c, tt));
        }
        Scheduler.later(total + 1, () -> holeEnd(sw, user, c, id));
    }

    private void holeTick(ServerLevel sw, Player user, Vec3 c, int t) {
        final DustParticleOptions violet = new DustParticleOptions(new Vector3f(0.5f, 0.1f, 0.9f), 1.8f);
        for (int ring = 0; ring < 3; ring++) {
            double r = 3 + ring * 2.6;
            for (int i = 0; i < 9; i++) {
                double a = Math.PI * 2 * i / 9 + t * (0.38 - ring * 0.06);
                Fx.burst(sw, violet, c.x + Math.cos(a) * r,
                        c.y + Math.sin(a * 2 + t * 0.1) * 0.3, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
            }
        }
        if (t % 2 == 0) Fx.burst(sw, ParticleTypes.PORTAL, c.x, c.y, c.z, 12, 3, 3, 3, 0.55);
        if (t % 4 == 0) Fx.burst(sw, ParticleTypes.SQUID_INK, c.x, c.y, c.z, 4, 1.2, 1.2, 1.2, 0.04);
        for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(16), e -> !friend(e, user))) {
            Vec3 mid = e.position().add(0, e.getBbHeight() / 2, 0);
            Vec3 to = c.subtract(mid);
            double d = to.length();
            if (d < 0.5) continue;
            Vec3 pull = to.normalize().scale(Math.min(0.9, 6.0 / (d + 2)));
            Vec3 v = e.getDeltaMovement().scale(0.5).add(pull);
            launch(e, v.x, v.y, v.z);
            e.fallDistance = 0;
            if (d < 3 && t % 10 == 0) {
                e.hurt(sw.damageSources().magic(), 8f);
            }
        }
        if (t % 10 == 0) {
            Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.BEACON_AMBIENT, 3f, 0.5f);
            Fx.screen(sw, c, 40, 0f, 0.8f, 10, 0x7733CC);
        }
    }

    private void holeEnd(ServerLevel sw, Player user, Vec3 c, int id) {
        Fx.cmd(sw, "kill @e[tag=lbm" + id + "]");
        sw.explode(user, c.x, c.y, c.z, 6f, Level.ExplosionInteraction.NONE);
        DustParticleOptions violetImpact = new DustParticleOptions(new Vector3f(0.64f, 0.22f, 1.0f), 2.1f);
        Fx.epicImpact(sw, c, violetImpact, ParticleTypes.REVERSE_PORTAL, 9.0, 0xAA66FF);
        Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.GENERIC_EXPLODE, 4f, 0.5f);
        for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(16), e -> !friend(e, user))) {
            Vec3 away = e.position().subtract(c);
            away = away.lengthSqr() < 0.01 ? new Vec3(1, 0, 0) : away.normalize();
            launch(e, away.x * 2.5, 0.8, away.z * 2.5);
            e.hurt(sw.damageSources().magic(), 40f);
        }
        final DustParticleOptions violet = new DustParticleOptions(new Vector3f(0.5f, 0.1f, 0.9f), 2.0f);
        for (int k = 0; k < 5; k++) {
            final double r = 2.5 + k * 3.1;
            Scheduler.later(k + 1, () -> {
                Fx.ring(sw, violet, c.x, c.y + 0.1, c.z, r, 18);
                Fx.ring(sw, ParticleTypes.REVERSE_PORTAL, c.x, c.y + 0.4, c.z, r * 0.72, 18);
            });
        }
    }

    // ---------------- 12: FROST NOVA ----------------
    private void frostNova(ServerLevel sw, Player user) {
        msg(user, "\u00a7b\u00a7lFROST NOVA!");
        final Vec3 c = user.position();
        final double radius = 14;
        final List<LivingEntity> victims = sw.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(radius),
                e -> !friend(e, user) && e.distanceToSqr(c) <= radius * radius);
        final DustParticleOptions ice = new DustParticleOptions(new Vector3f(0.6f, 0.9f, 1.0f), 1.8f);
        Fx.sound(sw, user.blockPosition(), SoundEvents.GLASS_BREAK, 3f, 0.6f);
        Fx.screen(sw, c, 48, 0.5f, 1.5f, 10, 0xBFEFFF);
        for (LivingEntity e : victims) {
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 6));
            e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0, false, false));
            e.setTicksFrozen(300);
            e.hurt(sw.damageSources().magic(), 100000f);
        }
        for (int t = 0; t < 7; t++) {
            final int tick = t;
            final double r = (t + 1) * 2.0;
            Scheduler.later(t + 1, () -> {
                Fx.ring(sw, ice, c.x, c.y + 0.3, c.z, r, 28);
                if (tick % 2 == 0) Fx.ring(sw, ParticleTypes.SNOWFLAKE, c.x, c.y + 0.6, c.z, r, 24);
            });
        }
        Scheduler.later(10, () -> {
            for (LivingEntity e : victims) {
                if (!e.isAlive()) continue;
                e.hurt(sw.damageSources().magic(), 30f);
                Fx.burst(sw, ParticleTypes.SNOWFLAKE, e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(), 18, 0.45, 0.6, 0.45, 0.12);
            }
            Fx.sound(sw, user.blockPosition(), SoundEvents.GLASS_BREAK, 3f, 1.1f);
        });
    }

    // ---------------- 13: TORNADO ----------------
    private void tornado(ServerLevel sw, Player user) {
        msg(user, "\u00a77\u00a7lHURRICANE!");
        Target tg = pickTarget(sw, user, 50);
        final Vec3 c = tg.pos();
        final int total = 90;
        Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.PHANTOM_FLAP, 3f, 0.5f);
        final DustParticleOptions gray = new DustParticleOptions(new Vector3f(0.8f, 0.8f, 0.85f), 1.8f);
        for (int t = 0; t < total; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                for (int h = 0; h <= 12; h += 3) {
                    double r = 1 + h * 0.48;
                    for (int side = 0; side < 2; side++) {
                        double a = tt * 0.42 + h * 0.62 + side * Math.PI;
                        double px = c.x + Math.cos(a) * r;
                        double py = c.y + h * 1.0;
                        double pz = c.z + Math.sin(a) * r;
                        Fx.burst(sw, tt % 2 == 0 ? ParticleTypes.CLOUD : gray,
                                px, py, pz, 1, 0.03, 0.03, 0.03, 0.01);
                    }
                }
                if (tt % 4 == 0) for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(18, 30, 18),
                        e -> !friend(e, user))) {
                    double dx = e.getX() - c.x;
                    double dz = e.getZ() - c.z;
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d > 18) continue;
                    double len = Math.max(0.5, d);
                    double tx = -dz / len * 0.55;
                    double tz = dx / len * 0.55;
                    launch(e, tx - dx / len * 0.1, 0.2, tz - dz / len * 0.1);
                    e.fallDistance = 0;
                    if (tt % 12 == 0) {
                        e.hurt(sw.damageSources().magic(), 5f);
                    }
                }
                if (tt % 20 == 0) {
                    Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.PHANTOM_FLAP, 3f, 0.6f);
                    Fx.screen(sw, c, 40, 0f, 0.7f, 20, 0xDDDDDD);
                }
            });
        }
    }

    // ---------------- 14: DRAGON BREATH ----------------
    private void dragonBreath(ServerLevel sw, Player user) {
        msg(user, "\u00a76\u00a7lDRAGON BREATH!");
        Fx.sound(sw, user.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, 3f, 0.8f);
        Fx.screen(sw, user.position(), 48, 0.18f, 0.7f, 20, 0xFF7A1A);
        for (int t = 0; t < 28; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> breathTick(sw, user, tt));
        }
    }

    private void breathTick(ServerLevel sw, Player user, int t) {
        if (gone(sw, user)) return;
        Vec3 eye = user.getEyePosition();
        Vec3 dir = user.getLookAngle();
        for (double d = 2; d <= 22; d += 2.0) {
            Vec3 p = eye.add(dir.scale(d)).add(0, -0.3, 0);
            double spread = 0.3 + d * 0.22;
            Fx.burst(sw, ParticleTypes.FLAME, p.x, p.y, p.z, 2, spread * 0.4, spread * 0.4, spread * 0.4, 0.012);
            if (((int) d) % 8 == 0) Fx.burst(sw, ParticleTypes.SOUL_FIRE_FLAME,
                    p.x, p.y, p.z, 1, spread * 0.3, spread * 0.3, spread * 0.3, 0.008);
        }
        if (t % 4 == 0) {
            Vec3 end = eye.add(dir.scale(22));
            for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, new AABB(eye, end).inflate(6), e -> !friend(e, user))) {
                Vec3 to = e.position().add(0, e.getBbHeight() / 2, 0).subtract(eye);
                double dist = to.length();
                if (dist > 22 || dist < 0.1) continue;
                if (to.normalize().dot(dir) < 0.88) continue;
                e.hurt(sw.damageSources().magic(), 14f);
                e.setSecondsOnFire(8);
            }
            Fx.sound(sw, user.blockPosition(), SoundEvents.BLAZE_SHOOT, 2f, 0.5f);
        }
    }

    private static List<EntityType<?>> getProjectileTypes(ServerLevel sw) {
        if (PROJECTILE_TYPE_CACHE != null) return PROJECTILE_TYPE_CACHE;
        List<EntityType<?>> found = new ArrayList<>();
        for (EntityType<?> type : ForgeRegistries.ENTITY_TYPES) {
            Entity probe = null;
            try { probe = type.create(sw); } catch (Exception ignored) { }
            if (probe instanceof Projectile) found.add(type);
            if (probe != null) probe.discard();
        }
        if (found.isEmpty()) found.add(EntityType.ARROW);
        PROJECTILE_TYPE_CACHE = List.copyOf(found);
        return PROJECTILE_TYPE_CACHE;
    }

    // ---------------- 15: PROJECTILE STORM ----------------
    private void arrowStorm(ServerLevel sw, Player user) {
        msg(user, "\u00a7e\u00a7lPROJECTILE STORM!");
        Target tg = pickTarget(sw, user, 100);
        final Vec3 c = tg.pos();
        final DustParticleOptions red = new DustParticleOptions(new Vector3f(1.0f, 0.2f, 0.2f), 1.6f);
        // Discover registered vanilla/modded projectile types once; avoid probing every mod entity on every cast.
        final List<EntityType<?>> projectileTypes = getProjectileTypes(sw);
        Fx.sound(sw, BlockPos.containing(c.x, c.y, c.z), SoundEvents.ARROW_SHOOT, 3f, 0.6f);
        for (int t = 0; t < 40; t++) {
            final int tt = t;
            Scheduler.later(t + 1, () -> {
                if (tt % 5 == 0) Fx.ring(sw, red, c.x, c.y + 0.3, c.z, 12, 24);
                for (int k = 0; k < 4; k++) {
                    EntityType<?> type = projectileTypes.get(sw.random.nextInt(projectileTypes.size()));
                    Entity spawned = null;
                    try { spawned = type.create(sw); } catch (Exception ignored) { }
                    if (!(spawned instanceof Projectile projectile)) {
                        if (spawned != null) spawned.discard();
                        continue;
                    }
                    double ox = (sw.random.nextDouble() - 0.5) * 20;
                    double oz = (sw.random.nextDouble() - 0.5) * 20;
                    projectile.setPos(c.x + ox, c.y + 24 + sw.random.nextDouble() * 12, c.z + oz);
                    projectile.setOwner(user);
                    projectile.setDeltaMovement((sw.random.nextDouble() - 0.5) * 0.35, -2.8 - sw.random.nextDouble(), (sw.random.nextDouble() - 0.5) * 0.35);
                    sw.addFreshEntity(projectile);
                }
            });
        }
    }

    // ---------------- 16: BLINK STRIKE ----------------
    private void blinkStrike(ServerLevel sw, Player user) {
        msg(user, "\u00a7e\u00a7lBLINK STRIKE!");
        Vec3 eye = user.getEyePosition();
        Vec3 dir = user.getLookAngle();
        Target tg = pickTarget(sw, user, 80);
        double dist = eye.distanceTo(tg.pos());
        Vec3 p = eye.add(dir.scale(Math.max(1.0, dist - 2.0)));
        Vec3 from = user.position();
        final DustParticleOptions trail = new DustParticleOptions(new Vector3f(1.0f, 0.9f, 0.0f), 1.8f);
        for (double d = 0; d <= dist; d += 1.0) {
            Vec3 q = eye.add(dir.scale(d));
            Fx.burst(sw, trail, q.x, q.y - 0.5, q.z, 3, 0.2, 0.2, 0.2, 0);
            Fx.burst(sw, ParticleTypes.END_ROD, q.x, q.y - 0.5, q.z, 1, 0.1, 0.1, 0.1, 0.02);
        }
        Fx.sound(sw, user.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, 2f, 1f);
        if (user instanceof ServerPlayer sp) {
            sp.teleportTo(p.x, p.y - 1.0, p.z);
        } else {
            user.moveTo(p.x, p.y - 1.0, p.z);
        }
        final Vec3 to = new Vec3(p.x, p.y - 1.0, p.z);

        for (Vec3 pos : new Vec3[]{from, to}) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sw);
            if (bolt != null) {
                bolt.moveTo(pos.x, pos.y, pos.z);
                bolt.setVisualOnly(true);
                sw.addFreshEntity(bolt);
            }
        }
        Fx.sound(sw, BlockPos.containing(to.x, to.y, to.z), SoundEvents.ENDERMAN_TELEPORT, 2f, 0.7f);
        Fx.screen(sw, to, 48, 0.8f, 3.0f, 12, 0xFFF07A);
        for (LivingEntity e : sw.getEntitiesOfClass(LivingEntity.class, new AABB(to, to).inflate(6), e -> !friend(e, user))) {
            if (e.distanceToSqr(to) > 36) continue;
            e.hurt(sw.damageSources().indirectMagic(user, user), 30f);
            Vec3 away = e.position().subtract(to);
            away = away.lengthSqr() < 0.01 ? new Vec3(1, 0, 0) : away.normalize();
            launch(e, away.x * 1.5, 0.6, away.z * 1.5);
        }
        for (int k = 0; k < 4; k++) {
            final double r = 1.5 + k * 1.5;
            Scheduler.later(k + 1, () -> Fx.ring(sw, trail, to.x, to.y + 0.3, to.z, r, 36));
        }
    }

    // ---------------- 17: OVERDRIVE ----------------
    /** Short offensive burst: deliberately no resistance, healing, or fire immunity. */
    private void overdrive(ServerLevel sw, Player user) {
        msg(user, "\u00a7c\u00a7lOVERDRIVE — BERSERK!");
        int dur = 300; // 15 seconds; Lucky Ascension remains the long all-round buff.
        user.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, dur, 3));
        user.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, dur, 3));
        user.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, dur, 3));
        user.addEffect(new MobEffectInstance(MobEffects.JUMP, dur, 2));
        Fx.sound(sw, user.blockPosition(), SoundEvents.BLAZE_SHOOT, 2f, 0.65f);
        Fx.screen(sw, user.position(), 28, 0.22f, 0.45f, 7, 0xFF5522);
        Fx.ring(sw, ParticleTypes.FLAME, user.getX(), user.getY() + 0.2, user.getZ(), 2.1, 20);
        Fx.burst(sw, ParticleTypes.CRIT, user.getX(), user.getY() + 1, user.getZ(), 18, 0.7, 0.8, 0.7, 0.12);
        for (int t = 0; t < 8; t++) {
            final int tt = t;
            Scheduler.later(t * 24 + 1, () -> {
                if (gone(sw, user)) return;
                double a = tt * Math.PI / 4.0;
                double x = user.getX() + Math.cos(a) * 0.75;
                double z = user.getZ() + Math.sin(a) * 0.75;
                Fx.burst(sw, ParticleTypes.FLAME, x, user.getY() + 0.8, z, 2, 0.02, 0.05, 0.02, 0.01);
            });
        }
    }

    // ---------------- 18+: DISTINCT ASCENDED POWERS ----------------

    /** Capture a small rolling history so Time Replay can restore a real recent position. */
    public static void captureSnapshots(MinecraftServer server) {
        Set<UUID> online = new HashSet<>();
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            UUID id = player.getUUID();
            online.add(id);
            Deque<PlayerSnapshot> history = PLAYER_HISTORY.computeIfAbsent(id, ignored -> new ArrayDeque<>());
            history.addLast(new PlayerSnapshot(player.position(), player.getHealth(), player.getYRot(),
                    player.getXRot(), player.level().dimension()));
            while (history.size() > SNAPSHOT_CAPACITY) history.removeFirst();
        }
        PLAYER_HISTORY.keySet().retainAll(online);
    }

    private static int activateShield(Player user, int duration) {
        UUID playerId = user.getUUID();
        int token = ++beamCounter;
        SHIELD_TOKENS.put(playerId, token);
        SHIELDED.add(playerId);
        Scheduler.later(duration, () -> {
            if (SHIELD_TOKENS.getOrDefault(playerId, -1) == token) {
                SHIELDED.remove(playerId);
                SHIELD_TOKENS.remove(playerId);
            }
        });
        return token;
    }

    private void yellowFlight(ServerLevel sw, Player user) {
        msg(user, "\u00a7e\u00a7lYELLOW FLIGHT!");
        if (user instanceof ServerPlayer player && !player.isCreative() && !player.isSpectator()) {
            boolean oldMayFly = player.getAbilities().mayfly;
            boolean oldFlying = player.getAbilities().flying;
            player.getAbilities().mayfly = true;
            player.getAbilities().flying = true;
            player.onUpdateAbilities();
            Scheduler.later(1200, () -> {
                if (!player.isRemoved() && player.isAlive() && !player.isCreative() && !player.isSpectator()) {
                    player.getAbilities().mayfly = oldMayFly;
                    player.getAbilities().flying = oldMayFly && oldFlying;
                    player.onUpdateAbilities();
                }
            });
        } else {
            user.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 80, 1, false, false));
            user.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 1200, 0, false, false));
        }
        user.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 1200, 1));
        Fx.screen(sw, user.position(), 64, 0.35f, 0.5f, 10, 0xFFFF00);
        Fx.sound(sw, user.blockPosition(), SoundEvents.ELYTRA_FLYING, 1.4f, 1.3f);
        // A brief accent every two seconds keeps the gold trail readable rather than opaque.
        for (int t = 0; t < 30; t++) {
            Scheduler.later(t * 40 + 1, () -> {
                if (gone(sw, user)) return;
                Fx.burst(sw, YELLOW, user.getX(), user.getY() + 0.8, user.getZ(), 5, 0.3, 0.4, 0.3, 0.02);
                Fx.burst(sw, ParticleTypes.END_ROD, user.getX(), user.getY() + 1.0, user.getZ(), 2, 0.2, 0.25, 0.2, 0.01);
            });
        }
    }

    private void timeStop(ServerLevel sw, Player user) {
        msg(user, "\u00a7b\u00a7lTIME STOP!");
        Vec3 center = user.position();
        List<Mob> stopped = sw.getEntitiesOfClass(Mob.class, new AABB(center, center).inflate(24),
                mob -> !friend(mob, user));
        Map<Mob, Boolean> previousAi = new HashMap<>();
        for (Mob mob : stopped) {
            previousAi.put(mob, mob.isNoAi());
            mob.setNoAi(true);
            mob.setDeltaMovement(Vec3.ZERO);
            mob.hurtMarked = true;
        }
        for (LivingEntity entity : sw.getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(24),
                target -> target != user && !friend(target, user))) {
            entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 65, 7, false, false));
            entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 65, 4, false, false));
            entity.addEffect(new MobEffectInstance(MobEffects.GLOWING, 65, 0, false, false));
        }
        user.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 80, 2));
        Fx.sound(sw, user.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, 2.4f, 0.6f);
        Fx.screen(sw, center, 80, 0.3f, 0.5f, 8, 0x44DDFF);
        for (int i = 0; i < 4; i++) {
            final int tick = i;
            Scheduler.later(i * 3 + 1, () -> Fx.ring(sw, ParticleTypes.END_ROD,
                    center.x, center.y + 0.5 + tick * 0.5, center.z, 3 + tick * 2, 24));
        }
        holdTimeStop(sw, stopped, previousAi, 60);
    }

    private void holdTimeStop(ServerLevel sw, List<Mob> stopped, Map<Mob, Boolean> previousAi, int ticksRemaining) {
        for (Mob mob : stopped) {
            if (mob.isAlive() && !mob.isRemoved()) {
                mob.setDeltaMovement(Vec3.ZERO);
                mob.hurtMarked = true;
            }
        }
        if (ticksRemaining <= 0) {
            for (Mob mob : stopped) {
                Boolean hadNoAi = previousAi.get(mob);
                if (hadNoAi != null && !mob.isRemoved()) mob.setNoAi(hadNoAi);
            }
            return;
        }
        Scheduler.later(1, () -> holdTimeStop(sw, stopped, previousAi, ticksRemaining - 1));
    }

    /** A short acceleration dash, deliberately different from Overdrive's long combat buffs. */
    private void timeSurge(ServerLevel sw, Player user) {
        msg(user, "\u00a7d\u00a7lTIME SURGE!");
        Vec3 direction = user.getLookAngle();
        push(user, direction.x * 1.8, Math.max(0.15, direction.y * 1.25), direction.z * 1.8);
        user.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 180, 5));
        user.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 180, 4));
        user.addEffect(new MobEffectInstance(MobEffects.JUMP, 100, 2));
        user.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 180, 0));
        Vec3 start = user.position().subtract(direction.scale(4)).add(0, 0.7, 0);
        Vec3 end = user.position().add(0, 0.7, 0);
        Fx.line(sw, ParticleTypes.END_ROD, start.x, start.y, start.z, end.x, end.y, end.z, 14);
        Fx.sound(sw, user.blockPosition(), SoundEvents.ENDER_DRAGON_FLAP, 1.8f, 1.8f);
        Fx.screen(sw, user.position(), 48, 0.28f, 0.5f, 8, 0xCC66FF);
    }

    /** A compact void tear: burst damage and lingering debuffs, not another long gravity field. */
    private void voidRift(ServerLevel sw, Player user) {
        msg(user, "\u00a75\u00a7lVOID RIFT!");
        Target target = pickTarget(sw, user, 90);
        Vec3 center = target.pos();
        for (LivingEntity entity : sw.getEntitiesOfClass(LivingEntity.class,
                new AABB(center, center).inflate(12), e -> !friend(e, user) && e.distanceToSqr(center) <= 144)) {
            entity.hurt(sw.damageSources().magic(), 58f);
            if (entity.isAlive()) {
                entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 180, 1));
                entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0));
                entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 140, 2));
                Vec3 inward = center.subtract(entity.position());
                if (inward.lengthSqr() > 0.01) push(entity, inward.normalize().x * 1.2, 0.35, inward.normalize().z * 1.2);
            }
        }
        // A vertical, jagged slit is visually distinct from Black Hole's circular orbit.
        Fx.line(sw, ParticleTypes.REVERSE_PORTAL, center.x - 3, center.y - 2, center.z,
                center.x + 2.2, center.y + 5, center.z, 18);
        Fx.line(sw, ParticleTypes.PORTAL, center.x + 3, center.y - 2, center.z + 0.15,
                center.x - 2.2, center.y + 5, center.z + 0.15, 18);
        Fx.burst(sw, ParticleTypes.SQUID_INK, center.x, center.y + 1.5, center.z, 32, 1.2, 2.5, 1.2, 0.04);
        Fx.sound(sw, BlockPos.containing(center.x, center.y, center.z), SoundEvents.RESPAWN_ANCHOR_DEPLETE, 2.6f, 0.7f);
        Fx.screen(sw, center, 80, 0.45f, 1.0f, 10, 0x660066);
    }

    /** A real projected 4D hypercube: a pair of rotating cube frames joined by eight edges. */
    private void giantTesseract(ServerLevel sw, Player user) {
        msg(user, "\u00a75\u00a7lGIANT TESSERACT — DIMENSIONAL COLLAPSE!");
        Target target = pickTarget(sw, user, 90);
        Vec3 center = target.pos();
        Vec3 frameCenter = center.add(0, 10.0, 0);
        DustParticleOptions gold = new DustParticleOptions(new Vector3f(1.0f, 0.82f, 0.12f), 1.55f);

        Fx.sound(sw, BlockPos.containing(center.x, center.y, center.z), SoundEvents.WARDEN_SONIC_BOOM, 3.2f, 0.42f);
        Fx.sound(sw, BlockPos.containing(center.x, center.y, center.z), SoundEvents.AMETHYST_BLOCK_RESONATE, 2.6f, 0.55f);
        Fx.screen(sw, center, 100, 0.22f, 0.75f, 10, 0xFFF066);
        Fx.ring(sw, gold, center.x, center.y + 0.15, center.z, 5.0, 18);
        Fx.ring(sw, ParticleTypes.REVERSE_PORTAL, center.x, center.y + 0.25, center.z, 8.0, 18);

        // Render at half the simulation tick rate: readable rotation without filling the scene.
        for (int tick = 0; tick <= 42; tick += 2) {
            final int elapsed = tick;
            Scheduler.later(tick + 1, () -> {
                double progress = elapsed / 42.0;
                double size = 13.5 - progress * 9.7;
                Fx.tesseract(sw, gold, ParticleTypes.REVERSE_PORTAL, ParticleTypes.ELECTRIC_SPARK,
                        ParticleTypes.END_ROD, frameCenter.x, frameCenter.y, frameCenter.z,
                        size, elapsed * 0.065, 3);
                if (elapsed % 6 == 0) {
                    Fx.burst(sw, ParticleTypes.PORTAL, frameCenter.x, frameCenter.y, frameCenter.z,
                            7, 0.25, 0.45, 0.25, 0.08);
                    AABB pullZone = new AABB(center, center).inflate(19);
                    for (LivingEntity entity : sw.getEntitiesOfClass(LivingEntity.class, pullZone,
                            e -> !friend(e, user) && e.distanceToSqr(center) <= 19 * 19)) {
                        Vec3 inward = center.subtract(entity.position().add(0, entity.getBbHeight() * 0.5, 0));
                        if (inward.lengthSqr() > 0.05) {
                            Vec3 direction = inward.normalize();
                            push(entity, direction.x * 0.65, direction.y * 0.45 + 0.18, direction.z * 0.65);
                        }
                    }
                }
            });
        }

        Scheduler.later(46, () -> {
            // The collapse only affects entities; no blocks are destroyed.
            AABB capture = new AABB(center, center).inflate(18);
            for (LivingEntity entity : sw.getEntitiesOfClass(LivingEntity.class, capture,
                    e -> !friend(e, user) && e.distanceToSqr(center) <= 18 * 18)) {
                if (entity instanceof Player) {
                    entity.hurt(sw.damageSources().magic(), 150f);
                } else {
                    entity.discard();
                }
            }
            Fx.sound(sw, BlockPos.containing(center.x, center.y, center.z), SoundEvents.END_PORTAL_SPAWN, 4.0f, 0.55f);
            Fx.sound(sw, BlockPos.containing(center.x, center.y, center.z), SoundEvents.GENERIC_EXPLODE, 3.6f, 0.45f);
            Fx.epicImpact(sw, center.add(0, 1.2, 0), gold, ParticleTypes.ELECTRIC_SPARK, 13.5, 0xFFF066);
            for (int pulse = 0; pulse < 4; pulse++) {
                final int index = pulse;
                Scheduler.later(pulse * 2 + 1, () -> {
                    double radius = 3.5 + index * 4.0;
                    Fx.ring(sw, gold, center.x, center.y + 0.2, center.z, radius, 18);
                    Fx.ring(sw, ParticleTypes.REVERSE_PORTAL, center.x, center.y + 0.45, center.z,
                            radius * 0.76, 18);
                });
            }
        });
    }

    private void allyCommand(ServerLevel sw, Player user) {
        msg(user, "\u00a7a\u00a7lALLY COMMAND!");
        Target target = pickTarget(sw, user, 100);
        LivingEntity enemy = target.entity() != null && target.entity().isAlive() && !friend(target.entity(), user)
                ? target.entity() : null;
        String ownerTag = "lbm_owner_" + user.getUUID();
        int count = 0;
        for (Entity entity : sw.getAllEntities()) {
            if (!(entity instanceof Mob mob) || !mob.isAlive() || !mob.getTags().contains(ownerTag)) continue;
            mob.setTarget(enemy);
            mob.setAggressive(enemy != null);
            mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 600, 3));
            mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 600, 2));
            if (enemy != null) mob.getNavigation().moveTo(enemy, 1.4);
            count++;
        }
        msg(user, "\u00a7eCommand sent to " + count + " of your allies.");
        Fx.burst(sw, ParticleTypes.HAPPY_VILLAGER, user.getX(), user.getY() + 1, user.getZ(), 24, 1, 1, 1, 0.12);
        Fx.sound(sw, user.blockPosition(), SoundEvents.VILLAGER_YES, 1.6f, 1.2f);
    }

    private void luckyAscension(ServerLevel sw, Player user) {
        msg(user, "\u00a76\u00a7lLUCKY ASCENSION!");
        user.setHealth(user.getMaxHealth());
        MobEffectInstance[] buffs = {
                new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 2400, 4),
                new MobEffectInstance(MobEffects.REGENERATION, 2400, 4),
                new MobEffectInstance(MobEffects.DAMAGE_BOOST, 2400, 5),
                new MobEffectInstance(MobEffects.ABSORPTION, 2400, 8),
                new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 2400, 3),
                new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 2400, 0),
                new MobEffectInstance(MobEffects.WATER_BREATHING, 2400, 0),
                new MobEffectInstance(MobEffects.NIGHT_VISION, 2400, 0)
        };
        for (MobEffectInstance effect : buffs) user.addEffect(effect);
        Fx.screen(sw, user.position(), 80, 0.65f, 1.5f, 14, 0xFFFF00);
        Fx.sound(sw, user.blockPosition(), SoundEvents.PLAYER_LEVELUP, 3.5f, 0.75f);
        Fx.ring(sw, YELLOW, user.getX(), user.getY() + 0.25, user.getZ(), 3.5, 24);
        Fx.burst(sw, ParticleTypes.TOTEM_OF_UNDYING, user.getX(), user.getY() + 1.0, user.getZ(), 32,
                0.6, 0.9, 0.6, 0.12);
    }

    /** Reality Break swaps the positions of enemies in a target zone and scrambles them. */
    private void realityBreak(ServerLevel sw, Player user) {
        msg(user, "\u00a7c\u00a7lREALITY BREAK — POSITION SHUFFLE!");
        Target target = pickTarget(sw, user, 100);
        Vec3 center = target.pos();
        List<LivingEntity> victims = sw.getEntitiesOfClass(LivingEntity.class,
                new AABB(center, center).inflate(16), e -> !friend(e, user) && e.distanceToSqr(center) <= 256);
        List<Vec3> positions = new ArrayList<>(victims.size());
        for (LivingEntity entity : victims) positions.add(entity.position());
        // Rotate by a non-zero offset: unlike a random shuffle, this guarantees a real swap
        // whenever at least two victims are present (so the ability never feels like a rename only).
        if (positions.size() > 1) {
            int shift = 1 + sw.random.nextInt(positions.size() - 1);
            List<Vec3> rotated = new ArrayList<>(positions.size());
            for (int i = 0; i < positions.size(); i++) rotated.add(positions.get((i + shift) % positions.size()));
            positions = rotated;
        }
        for (int i = 0; i < victims.size(); i++) {
            LivingEntity entity = victims.get(i);
            entity.hurt(sw.damageSources().magic(), 18f);
            entity.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 120, 0));
            entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1));
            Vec3 destination;
            if (victims.size() == 1) {
                double angle = sw.random.nextDouble() * Math.PI * 2;
                double distance = 5.0 + sw.random.nextDouble() * 5.0;
                destination = entity.position().add(Math.cos(angle) * distance, 0, Math.sin(angle) * distance);
            } else {
                destination = positions.get(i);
            }
            entity.teleportTo(destination.x, destination.y, destination.z);
        }
        // Two small crossed tears imply a plane being rearranged; no broad particle explosion.
        Fx.line(sw, ParticleTypes.CRIT, center.x - 7, center.y - 2, center.z - 1,
                center.x + 7, center.y + 5, center.z + 1, 16);
        Fx.line(sw, ParticleTypes.PORTAL, center.x + 7, center.y - 2, center.z + 1,
                center.x - 7, center.y + 5, center.z - 1, 16);
        Fx.sound(sw, BlockPos.containing(center.x, center.y, center.z), SoundEvents.GLASS_BREAK, 2.2f, 0.7f);
        Fx.screen(sw, center, 90, 0.24f, 0.8f, 8, 0xFF22AA);
    }

    /** Marks a targeted group with a time debt: slow now, delayed strike later. */
    private void chronoBurst(ServerLevel sw, Player user) {
        msg(user, "\u00a7b\u00a7lCHRONO BURST — TIME DEBT!");
        Target target = pickTarget(sw, user, 72);
        Vec3 center = target.pos();
        List<LivingEntity> marked = sw.getEntitiesOfClass(LivingEntity.class,
                new AABB(center, center).inflate(12), e -> !friend(e, user) && e.distanceToSqr(center) <= 144);
        for (LivingEntity entity : marked) {
            entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 70, 7));
            entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 90, 1));
            entity.addEffect(new MobEffectInstance(MobEffects.GLOWING, 50, 0, false, false));
        }
        user.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 120, 2));
        Fx.sound(sw, BlockPos.containing(center.x, center.y, center.z), SoundEvents.AMETHYST_BLOCK_CHIME, 2.3f, 0.45f);
        Fx.line(sw, ParticleTypes.END_ROD, center.x, center.y - 2, center.z, center.x, center.y + 6, center.z, 12);
        Fx.burst(sw, ParticleTypes.REVERSE_PORTAL, center.x, center.y + 1, center.z, 18, 1.2, 1.4, 1.2, 0.04);
        Fx.screen(sw, center, 64, 0.2f, 0.5f, 7, 0x00FFFF);
        Scheduler.later(40, () -> {
            for (LivingEntity entity : marked) {
                if (!entity.isAlive() || entity.isRemoved() || entity.level() != sw) continue;
                if (entity.distanceToSqr(center) <= 196) {
                    entity.hurt(sw.damageSources().magic(), 28f);
                    Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, entity.getX(), entity.getY() + entity.getBbHeight() / 2,
                            entity.getZ(), 5, 0.15, 0.25, 0.15, 0.08);
                }
            }
            Fx.sound(sw, BlockPos.containing(center.x, center.y, center.z), SoundEvents.LIGHTNING_BOLT_THUNDER, 2.2f, 1.3f);
        });
    }

    /** Randomly routes to another already loaded dimension, including modded dimensions. */
    private void dimensionShift(ServerLevel sw, Player user) {
        List<ServerLevel> destinations = new ArrayList<>();
        for (ServerLevel level : sw.getServer().getAllLevels()) {
            if (level != sw) destinations.add(level);
        }
        if (destinations.isEmpty()) {
            msg(user, "\u00a7cNo other loaded dimensions are available.");
            return;
        }
        ServerLevel destination = destinations.get(sw.random.nextInt(destinations.size()));
        BlockPos spawn = destination.getSharedSpawnPos();
        BlockPos safe = spawn.above(1);
        for (int up = 1; up <= 16; up++) {
            BlockPos candidate = spawn.above(up);
            if (destination.getBlockState(candidate).isAir()
                    && destination.getBlockState(candidate.above()).isAir()
                    && !destination.getBlockState(candidate.below()).isAir()) {
                safe = candidate;
                break;
            }
        }
        Vec3 from = user.position();
        Fx.burst(sw, ParticleTypes.REVERSE_PORTAL, from.x, from.y + 1, from.z, 36, 1, 1, 1, 0.12);
        Fx.sound(sw, user.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, 2.5f, 0.8f);
        if (user instanceof ServerPlayer player) {
            player.teleportTo(destination, safe.getX() + 0.5, safe.getY(), safe.getZ() + 0.5,
                    player.getYRot(), player.getXRot());
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 160, 2));
            Fx.burst(destination, ParticleTypes.PORTAL, player.getX(), player.getY() + 1, player.getZ(), 36, 1, 1.5, 1, 0.1);
            player.displayClientMessage(Component.literal("§5Dimension Shift → " + destination.dimension().location()), true);
        }
    }

    private void cosmicNova(ServerLevel sw, Player user) {
        msg(user, "\u00a7d\u00a7lCOSMIC NOVA!");
        Vec3 center = user.position();
        for (LivingEntity entity : sw.getEntitiesOfClass(LivingEntity.class,
                new AABB(center, center).inflate(22), e -> !friend(e, user))) {
            entity.hurt(sw.damageSources().magic(), 70f);
            Vec3 away = entity.position().subtract(center);
            if (away.lengthSqr() > 0.01) {
                away = away.normalize();
                push(entity, away.x * 2.2, 1.1, away.z * 2.2);
            }
        }
        Fx.sound(sw, user.blockPosition(), SoundEvents.END_PORTAL_SPAWN, 3.2f, 0.7f);
        DustParticleOptions cosmic = new DustParticleOptions(new Vector3f(0.65f, 0.25f, 1.0f), 1.9f);
        Fx.epicImpact(sw, center, cosmic, ParticleTypes.PORTAL, 13.0, 0xAA66FF);
        for (int i = 0; i < 4; i++) {
            final int pulse = i;
            Scheduler.later(i * 3 + 1, () -> {
                double radius = 4 + pulse * 4.5;
                Fx.ring(sw, cosmic, center.x, center.y + 0.25, center.z, radius, 18);
                Fx.ring(sw, ParticleTypes.END_ROD, center.x, center.y + 0.55, center.z, radius * 0.82, 18);
            });
        }
    }

    /** Opens a registry-backed item picker; the client submits only the chosen resource ID. */
    private void itemWish(ServerLevel sw, Player user) {
        if (!(user instanceof ServerPlayer player)) return;
        msg(user, "\u00a76Lucky Wish catalogue opened — choose any registered item.");
        LuckyBlockMod.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenItemWishPacket());
        Fx.burst(sw, ParticleTypes.TOTEM_OF_UNDYING, user.getX(), user.getY() + 1, user.getZ(), 24, 0.6, 0.8, 0.6, 0.12);
        Fx.sound(sw, user.blockPosition(), SoundEvents.PLAYER_LEVELUP, 1.6f, 1.3f);
    }

    private void timeReplay(ServerLevel sw, Player user) {
        msg(user, "\u00a7d\u00a7lTIME REPLAY!");
        Deque<PlayerSnapshot> history = PLAYER_HISTORY.get(user.getUUID());
        PlayerSnapshot snapshot = null;
        if (history != null && history.size() >= 20) {
            PlayerSnapshot[] snapshots = history.toArray(new PlayerSnapshot[0]);
            int targetIndex = Math.max(0, snapshots.length - 61); // roughly three seconds ago
            snapshot = snapshots[targetIndex];
        }
        Vec3 from = user.position();
        if (snapshot != null && snapshot.dimension().equals(sw.dimension()) && user instanceof ServerPlayer player) {
            Vec3 old = snapshot.position();
            player.teleportTo(sw, old.x, old.y, old.z, snapshot.yaw(), snapshot.pitch());
            user.setHealth(Math.min(user.getMaxHealth(), Math.max(user.getHealth(), snapshot.health())));
            user.fallDistance = 0;
            user.removeEffect(MobEffects.WITHER);
            user.removeEffect(MobEffects.POISON);
            user.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
            user.removeEffect(MobEffects.CONFUSION);
            user.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 160, 2));
            Fx.line(sw, ParticleTypes.REVERSE_PORTAL, from.x, from.y + 1, from.z,
                    old.x, old.y + 1, old.z, 20);
            Fx.burst(sw, ParticleTypes.END_ROD, old.x, old.y + 1, old.z, 30, 0.6, 1, 0.6, 0.08);
            msg(user, "\u00a7dReplayed a recent position and recovered lost health.");
        } else {
            user.setHealth(user.getMaxHealth());
            user.removeEffect(MobEffects.WITHER);
            user.removeEffect(MobEffects.POISON);
            user.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
            user.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 2));
            Fx.burst(sw, ParticleTypes.REVERSE_PORTAL, from.x, from.y + 1, from.z, 24, 0.8, 1, 0.8, 0.08);
            msg(user, "§dNo recent snapshot was available; health and harmful effects were restored.");
        }
        Fx.sound(sw, user.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, 2.4f, 0.6f);
        Fx.screen(sw, user.position(), 64, 0.25f, 0.45f, 8, 0xDD88FF);
    }

    /**
     * Calls a colossal tesseract down from the sky. Hostiles and projectiles in its
     * footprint are lifted into the frame and banished when it folds shut.
     */
    private void spatialDeflection(ServerLevel sw, Player user) {
        msg(user, "\u00a75\u00a7lSPATIAL DEFLECTION — VOID CONTAINMENT!");
        Target target = pickTarget(sw, user, 100);
        Vec3 center = target.pos();
        Vec3 skyCenter = center.add(0, 22.0, 0);
        DustParticleOptions gold = new DustParticleOptions(new Vector3f(1.0f, 0.88f, 0.16f), 1.7f);
        DustParticleOptions violet = new DustParticleOptions(new Vector3f(0.45f, 0.14f, 0.9f), 1.45f);

        Fx.sound(sw, BlockPos.containing(center.x, center.y, center.z), SoundEvents.END_PORTAL_SPAWN, 4.0f, 0.42f);
        Fx.sound(sw, BlockPos.containing(center.x, center.y, center.z), SoundEvents.WARDEN_SONIC_BOOM, 3.4f, 0.5f);
        Fx.screen(sw, center, 140, 0.25f, 0.9f, 12, 0xB58AFF);
        Fx.ring(sw, gold, center.x, center.y + 0.2, center.z, 18, 18);
        Fx.ring(sw, violet, center.x, center.y + 0.35, center.z, 24, 18);
        Fx.line(sw, ParticleTypes.REVERSE_PORTAL, center.x - 18, center.y + 0.5, center.z,
                center.x + 18, center.y + 0.5, center.z, 18);
        Fx.line(sw, ParticleTypes.REVERSE_PORTAL, center.x, center.y + 0.5, center.z - 18,
                center.x, center.y + 0.5, center.z + 18, 18);

        // Mark enemies at the start, then steadily lift them toward the sky-frame.
        AABB captureZone = new AABB(center, center).inflate(22);
        for (LivingEntity entity : sw.getEntitiesOfClass(LivingEntity.class, captureZone,
                e -> !friend(e, user) && e.distanceToSqr(center) <= 22 * 22)) {
            entity.addEffect(new MobEffectInstance(MobEffects.GLOWING, 60, 0, false, false));
            entity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 45, 1, false, false));
            entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 45, 4, false, false));
        }

        for (int tick = 0; tick <= 42; tick += 2) {
            final int elapsed = tick;
            Scheduler.later(tick + 1, () -> {
                double progress = elapsed / 42.0;
                double size = 21.5 - progress * 17.5;
                Fx.tesseract(sw, ParticleTypes.END_ROD, violet, ParticleTypes.ELECTRIC_SPARK,
                        gold, skyCenter.x, skyCenter.y, skyCenter.z, size, elapsed * 0.055, 3);
                if (elapsed % 6 == 0) {
                    Fx.burst(sw, ParticleTypes.REVERSE_PORTAL, skyCenter.x, skyCenter.y, skyCenter.z,
                            9, 0.35, 0.65, 0.35, 0.14);
                    AABB liftZone = new AABB(center, center).inflate(22);
                    for (LivingEntity entity : sw.getEntitiesOfClass(LivingEntity.class, liftZone,
                            e -> !friend(e, user) && e.isAlive() && e.distanceToSqr(center) <= 22 * 22)) {
                        Vec3 toFrame = skyCenter.subtract(entity.position().add(0, entity.getBbHeight() * 0.5, 0));
                        double distance = toFrame.length();
                        if (distance > 0.01) {
                            Vec3 direction = toFrame.scale(1.0 / distance);
                            push(entity, direction.x * 0.7, Math.max(0.35, direction.y * 1.25), direction.z * 0.7);
                        }
                    }
                    // The field pulls incoming projectiles into the same capture point.
                    for (Projectile projectile : sw.getEntitiesOfClass(Projectile.class, liftZone,
                            p -> p.getOwner() != user && !p.getTags().contains("lbm_ally"))) {
                        Vec3 toFrame = skyCenter.subtract(projectile.position());
                        if (toFrame.lengthSqr() > 0.01) {
                            Vec3 direction = toFrame.normalize();
                            launch(projectile, direction.x * 1.8, direction.y * 1.8, direction.z * 1.8);
                        }
                    }
                }
            });
        }

        Scheduler.later(46, () -> {
            AABB finalZone = new AABB(center, center).inflate(22);
            for (Projectile projectile : sw.getEntitiesOfClass(Projectile.class, finalZone,
                    p -> p.getOwner() != user && !p.getTags().contains("lbm_ally"))) {
                projectile.discard();
            }
            for (Entity entity : sw.getEntities(null, finalZone, e -> e != user && !friend(e, user)
                    && e.position().distanceToSqr(center) <= 22 * 22)) {
                if (entity instanceof Player player) {
                    player.hurt(sw.damageSources().magic(), 150f);
                } else {
                    entity.discard();
                }
            }
            Fx.sound(sw, BlockPos.containing(center.x, center.y, center.z), SoundEvents.GENERIC_EXPLODE, 4.5f, 0.42f);
            Fx.sound(sw, BlockPos.containing(center.x, center.y, center.z), SoundEvents.END_PORTAL_SPAWN, 4.5f, 0.35f);
            Fx.epicImpact(sw, center.add(0, 2.0, 0), violet, ParticleTypes.REVERSE_PORTAL, 17.0, 0xB58AFF);
            Fx.burst(sw, ParticleTypes.POOF, skyCenter.x, skyCenter.y, skyCenter.z, 24, 2.4, 2.4, 2.4, 0.18);
            Fx.burst(sw, ParticleTypes.PORTAL, skyCenter.x, skyCenter.y, skyCenter.z, 24, 2.8, 2.8, 2.8, 0.26);
            for (int pulse = 0; pulse < 4; pulse++) {
                final int index = pulse;
                Scheduler.later(pulse * 2 + 1, () -> {
                    double radius = 5 + index * 4.2;
                    Fx.ring(sw, gold, center.x, center.y + 0.2, center.z, radius, 18);
                    Fx.ring(sw, ParticleTypes.REVERSE_PORTAL, center.x, center.y + 0.5, center.z,
                            radius * 0.72, 18);
                });
            }
        });
    }

    private void absoluteAegis(ServerLevel sw, Player user) {
        msg(user, "\u00a76\u00a7lABSOLUTE AEGIS!");
        activateShield(user, 1200);
        user.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 1200, 9));
        user.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 1200, 8));
        user.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 1200, 4));
        user.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 0));
        Fx.sound(sw, user.blockPosition(), SoundEvents.BEACON_ACTIVATE, 3.0f, 1.7f);
        Fx.screen(sw, user.position(), 80, 0.45f, 0.6f, 10, 0xFFFF00);
        for (int i = 0; i < 5; i++) {
            final int layer = i;
            Scheduler.later(i * 3 + 1, () -> Fx.ring(sw, YELLOW,
                    user.getX(), user.getY() + 0.25 + layer * 0.3, user.getZ(), 2 + layer * 0.9, 24));
        }
    }

    /** Focused chain lightning instead of Lightning Storm's broad random strike field. */
    private void thunderGod(ServerLevel sw, Player user) {
        msg(user, "\u00a7b\u00a7lTHUNDER GOD — CHAIN!");
        Target target = pickTarget(sw, user, 100);
        LivingEntity first = target.entity();
        if (first == null || !first.isAlive() || friend(first, user)) {
            Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, target.pos().x, target.pos().y + 1, target.pos().z, 28, 0.6, 1.0, 0.6, 0.2);
            Fx.sound(sw, user.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, 2.0f, 0.8f);
            return;
        }
        List<LivingEntity> chain = new ArrayList<>();
        chain.add(first);
        while (chain.size() < 7) {
            LivingEntity last = chain.get(chain.size() - 1);
            LivingEntity next = null;
            double bestDistance = 14 * 14;
            for (LivingEntity candidate : sw.getEntitiesOfClass(LivingEntity.class,
                    new AABB(last.blockPosition()).inflate(14), e -> !friend(e, user) && !chain.contains(e) && e.isAlive())) {
                double distance = candidate.distanceToSqr(last);
                if (distance < bestDistance) {
                    bestDistance = distance;
                    next = candidate;
                }
            }
            if (next == null) break;
            chain.add(next);
        }
        for (int i = 0; i < chain.size(); i++) {
            final int index = i;
            Scheduler.later(i * 3 + 1, () -> {
                LivingEntity entity = chain.get(index);
                if (!entity.isAlive()) return;
                LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sw);
                if (bolt != null) {
                    bolt.moveTo(entity.getX(), entity.getY(), entity.getZ());
                    bolt.setVisualOnly(true);
                    sw.addFreshEntity(bolt);
                }
                entity.hurt(sw.damageSources().indirectMagic(user, user), 52f);
                Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, entity.getX(), entity.getY() + 1, entity.getZ(), 18, 0.4, 0.8, 0.4, 0.15);
                if (index > 0) {
                    LivingEntity previous = chain.get(index - 1);
                    Fx.line(sw, ParticleTypes.ELECTRIC_SPARK, previous.getX(), previous.getY() + 1, previous.getZ(),
                            entity.getX(), entity.getY() + 1, entity.getZ(), 8);
                }
                Fx.sound(sw, entity.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, 2.0f, 1.0f + index * 0.08f);
            });
        }
        Fx.screen(sw, first.position(), 100, 0.35f, 1.0f, 10, 0x66CCFF);
    }

}
