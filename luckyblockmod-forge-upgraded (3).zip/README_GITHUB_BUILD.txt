Lucky Block Mod — GitHub Actions

The project root contains build.gradle, settings.gradle, gradle.properties, and src/.
The workflow is at .github/workflows/build.yml.

To use this archive as your GitHub repository, extract the ZIP locally and commit/upload the CONTENTS to the repository root. Do not upload only this ZIP if you want to edit the files through the GitHub web editor.

The workflow also supports a repository that contains only the source ZIP: it finds and extracts an archive containing build.gradle, then runs clean build and uploads build/libs/*.jar as an artifact.
